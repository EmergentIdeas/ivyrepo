window.$ = window.jQuery = require('jquery')
require('../../../test-resources/jquery-ui-1.12.1.custom/jquery-ui.js')

require('./index')


// var pageEditor = require('page-editor')
// 
// pageEditor.configure()

var crudTools = require('crud-tools')


crudTools.allowItemsSort()

