var UploadableImage = require('page-editor/uploadable-image')
var _ = require('underscore')
var resize = require('ei-pic-browser/resize-img')

$('input[data-treatement=image-upload]').each(function() {
	new UploadableImage(this)
})


var options = {
	serverDirectoryAttribute: 'data-image-dir',
	defaultImgDir: '/img',
	fileUploadUrlPrefix: '/files/upload/'

}


$('.site-gallery-slides-drop').each(function() {
	var $currentitem = $(this);
	var url;
	if(typeof $currentitem.attr(options.serverDirectoryAttribute) != 'undefined') {
		 url = $currentitem.attr(options.serverDirectoryAttribute);
	}
	if(!url || 0 === url.length) {
		url = options.defaultImgDir; 
	}
	if(url.charAt(0) == '/') {
		url = url.substring(1);
	}
	
	
	
	$currentitem.on('dragenter', function (e) {
		e.stopPropagation();
		e.preventDefault();
		$(this).css('outline', 'dashed 1px #66AFE9');
	});
	$currentitem.on('dragover', function (e) {
		e.stopPropagation();
		e.preventDefault();
	});
	$currentitem.on('dragstop dragend dragleave', function (e) {
		e.stopPropagation();
		e.preventDefault();
		$(this).css('outline', '');
	});
	$currentitem.on('drop', function(evt) {
		evt.stopPropagation();
		evt.preventDefault();
		$(this).css('outline', '');
		
		
		var files = evt.originalEvent.target.files
				|| evt.originalEvent.dataTransfer.files;
		if(files.length > 0) {
			// var file = files[0];
			
			_.each(files, function(file) {
				var reader  = new FileReader();
				
				reader.onloadend = function () {
					
					var result = resize(reader.result, $('.max-picture-width').val())
					$.ajax({
						url: options.fileUploadUrlPrefix + url,
						type: 'POST',
						cache: false,
						data: {
							dataUrl: result,
							dataFilename: file.name
						},
						success: function(data, textStatus, jqXHR) {
							var finalUrl = '/' + url + (url.endsWith('/') ? '' : '/') + file.name;
							
							var slideHtml = '<div class="slide" data-slide-id="__id__"' +
								'style="background-image: url(\'' + finalUrl + '\');">' +
								'<div class="options"><a class="edit">edit</a> <a class="delete">delete</a></div><div class="footer">' +
									'<div class="summary">' +
									'</div>' +
								'</div>' +
							'</div>'
							$('.site-gallery-slides').append(slideHtml)
						}
					});
					
					var parts = file.name.split('.')
					var ext = parts.pop()
					var thumbnailName = parts.join('.') + '-thumbnail.' + ext
					
					var thumbnail = resize(reader.result, $('.max-thumbnail-width').val())
					$.ajax({
						url: options.fileUploadUrlPrefix + url,
						type: 'POST',
						cache: false,
						data: {
							dataUrl: thumbnail,
							dataFilename: thumbnailName
						}
					});

					$.ajax({
						url: '/gallery-slide/create',
						type: 'POST',
						cache: false,
						data: {
							summary: '',
							description: '',
							image: '/' + url + '/' + file.name,
							thumbnail: '/' + url + '/' + thumbnailName,
							galleryId: $('.site-gallery-slides-drop').attr('data-gallery-id')
						}
					});
					

				}

				reader.readAsDataURL(file);
			})
			

		}
	});
	
});

