var menuSlide = require('./index')

menuSlide('.menu-open-button', '.page', '.menu-slide-menu')

