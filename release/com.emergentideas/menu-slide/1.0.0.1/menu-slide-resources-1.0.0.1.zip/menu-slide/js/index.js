/*
	Returns a object to which you can add open and close listeners (.open and .close)
*/
var $ = require('jquery')

var openClass = 'menu-slide-open'

var menuSlide = function(menuButtonSelector, pageContainerSelector, menuSelector) {
	var slider = {}
	
	$(menuButtonSelector).click(function(evt) {
		evt.preventDefault()
		evt.stopPropagation()
		if($('body').hasClass(openClass)) {
			$('body').removeClass(openClass)
			$('.menu-slide-open-cover').remove()
			if(slider.close) {
				slider.close()
			}
		}
		else {
			if(slider.open) {
				slider.open()
			}
			$('body').addClass(openClass)
			$('body').append('<div class="menu-slide-open-cover">&nbsp;</div>')
		}
	})
	$('body').click(function(evt) {
		if($('body').hasClass(openClass)) {
			$('body').removeClass(openClass)
			$('.menu-slide-open-cover').remove()
			if(slider.close) {
				slider.close()
			}
		}
	})
	
	return slider
}

module.exports = menuSlide
