var $ = require('jquery')
var menuMaker = require('./index')

var integrate = function(selector, menuFilePath) {
	var container = $(selector)
	if(container.length > 0) {
		$.get('/files/api/all-pages', function(pagesData) {
			$.get(menuFilePath, function(treeData) {
				if(typeof treeData == 'string') {
					treeData = JSON.parse(treeData)
				}
				var tree = menuMaker({
					wrapper: container, 
					treeData: treeData,
					pages: pagesData,
					writeBack: function(data) {
						$.post('/files/api/write' + menuFilePath, {
							data: btoa(data)
						})
					}
				})	
			})
			
		})
	}
}

module.exports = integrate