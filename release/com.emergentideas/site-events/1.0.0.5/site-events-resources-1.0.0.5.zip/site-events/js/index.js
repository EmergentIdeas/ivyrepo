var UploadableImage = require('page-editor/uploadable-image')
$('.event-form input[data-image-dir]').each(function() {
	new UploadableImage(this)
})