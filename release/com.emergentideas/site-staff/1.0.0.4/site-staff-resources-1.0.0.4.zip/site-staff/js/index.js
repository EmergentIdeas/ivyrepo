var UploadableImage = require('page-editor/uploadable-image')


$('.site-staff-form [data-image-dir]').each(function() {
	new UploadableImage(this)
})
