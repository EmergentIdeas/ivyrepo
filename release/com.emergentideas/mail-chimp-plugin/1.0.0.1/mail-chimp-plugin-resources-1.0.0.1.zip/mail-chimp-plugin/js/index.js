var $ = require('jquery')

var startOptions = {}
startOptions.ajaxAndCss = function() {
	$('.mailchimp-contact form').on('submit', function(evt) {
	    evt.preventDefault()
	    var $this = $(this)
		
		$this.find('button').prop('disabled', true)
		$this.closest('.mailchimp-contact').addClass('submitting')
		
	    $.ajax({
	        type: "POST",
	        url: $this.attr('action'),
	        data: $this.serialize()
	    }).done(function (data) {
	    	$this.closest('.mailchimp-contact').removeClass('submitting').addClass("success")
	    })
	})
}

module.exports = startOptions