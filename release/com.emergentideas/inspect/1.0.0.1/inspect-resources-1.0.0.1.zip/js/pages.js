
allMonthNames = [
         	    "January", "February", "March",
        	    "April", "May", "June",
        	    "July", "August", "September",
        	    "October", "November", "December"
        	]; 

function getMonthNameFromDate(d) {
	return allMonthNames[d.getMonth()];
}

function getShortMonthNameFromDate(d) {
	return getMonthNameFromDate(d).substr(0, 3);
}

function parseISO8601Date(s){
	 
	  // parenthese matches:
	  // year month day    hours minutes seconds  
	  // dotmilliseconds 
	  // tzstring plusminus hours minutes
	  var re = /(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)(\.\d+)?(Z|([+-])(\d\d):(\d\d))/;
	 
	  var d = [];
	  d = s.match(re);
	 
	  // "2010-12-07T11:00:00.000-09:00" parses to:
	  //  ["2010-12-07T11:00:00.000-09:00", "2010", "12", "07", "11",
	  //     "00", "00", ".000", "-09:00", "-", "09", "00"]
	  // "2010-12-07T11:00:00.000Z" parses to:
	  //  ["2010-12-07T11:00:00.000Z",      "2010", "12", "07", "11", 
	  //     "00", "00", ".000", "Z", undefined, undefined, undefined]
	 
	  if (! d) {
	    throw "Couldn't parse ISO 8601 date string '" + s + "'";
	  }
	 
	  // parse strings, leading zeros into proper ints
	  var a = [1,2,3,4,5,6,10,11];
	  for (var i in a) {
	    d[a[i]] = parseInt(d[a[i]], 10);
	  }
	  d[7] = parseFloat(d[7]);
	 
	  // Date.UTC(year, month[, date[, hrs[, min[, sec[, ms]]]]])
	  // note that month is 0-11, not 1-12
	  // see https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Date/UTC
	  var ms = Date.UTC(d[1], d[2] - 1, d[3], d[4], d[5], d[6]);
	 
	  // if there are milliseconds, add them
	  if (d[7] > 0) {  
	    ms += Math.round(d[7] * 1000);
	  }
	 
	  // if there's a timezone, calculate it
	  if (d[8] != "Z" && d[10]) {
	    var offset = d[10] * 60 * 60 * 1000;
	    if (d[11]) {
	      offset += d[11] * 60 * 1000;
	    }
	    if (d[9] == "+") {
	      ms -= offset;
	    }
	    else {
	      ms += offset;
	    }
	  }
	 
	  return new Date(ms);
	};
/*
if(!Date.prototype.monthNames) {
	Date.prototype.monthNames = [
	    "January", "February", "March",
	    "April", "May", "June",
	    "July", "August", "September",
	    "October", "November", "December"
	];
	
	Date.prototype.getMonthName = function() {
	    return this.monthNames[this.getMonth()];
	};
	Date.prototype.getShortMonthName = function () {
	    return this.getMonthName().substr(0, 3);
	};
}
*/
function loadAvailableTimesUI() {
	var url = '/api/v1/available-inpsection-times/' + buildingNumber;
	if(allSectors) {
		url += "?allSectors=true";
	}
	$.ajax(
		{
			url: url,
			cache: false
		}	
	).success(function(data) {
		times = {};
		$.each(data, function(index, appt){
			var d = parseISO8601Date(appt.periodStart);
			var month = times[getMonthNameFromDate(d)];
			if(!month) {
				month = { name: getMonthNameFromDate(d) };
				month.num = d.getMonth();
				times[month.name] = month;
				
			}
			
			var day = month[d.getDate()];
			if(!day) {
				day = { day: d.getDate(), slots: []};
				month[day.day] = day;
			}
			
			day.slots.push(appt);
		});
		
		var monthList = [];
		for(i in times) {
			monthList.push(times[i]);
		}
		monthList.sort(function(first, second) {
			return first.num - second.num;
		});
		var monthCount = 0;
		$.each(monthList, function(index, month) {
			$('.available-months').append(monthOption(month))
			monthCount++;
		});
		
		if(monthCount > 0) {
			$('.available-months a').first().click();
		}
		else {
			$('.calendar-view').append('<p>There are no upcoming inspection shifts available.</p>')
		}
	});
}

function getStartDayInMonth(month) {
	var d = new Date();
	d.setMonth(month);
	d.setDate(1);
	return d.getDay();
}

function getDaysInMonth(month) {
	var d = new Date();
	d.setMonth(month);
	d.setDate(1);
	var start = d.getTime();
	if(month == 11) {
		d.setMonth(0);
		d.setFullYear(d.getFullYear() + 1);
	}
	else {
		d.setMonth(d.getMonth() + 1);
	}
	
	var then = d.getTime()
	
	then += 60 * 60 * 1000;
	
	return Math.floor((then - start) / (24 * 60 * 60 * 1000));
}

function zeroPrefix(val) {
	var s = '' + val;
	if(s.length == 1) {
		s = '0' + s;
	}
	return s;
}

function renderTimeSlotsInDetailView(day, monthName, dayNum) {
	$('.available-times').html('<h2>' + monthName + " " + dayNum + '</h2><p>Click the time below to schedule.</p>');
	$.each(day.slots, function(index, val) {
		var start = parseISO8601Date(val.periodStart);
		var end = parseISO8601Date(val.periodEnd);
		
		var startMod = start.getHours() >= 12 ? "pm" : "am";
		var endMod = end.getHours() >= 12 ? "pm" : "am";
		
		val.humanRange = twelveHour(start.getHours()) + ':' + zeroPrefix(start.getMinutes()) + startMod + 
		' - ' + twelveHour(end.getHours()) + ':' + zeroPrefix(end.getMinutes()) + endMod;
		val.startTimestamp = parseISO8601Date(val.periodStart).getTime();
		val.endTimestamp = parseISO8601Date(val.periodEnd).getTime();
		if(isAdmin) {
			$('.available-times').append(adminTimeSlot(val));
		}
		else {
			$('.available-times').append(timeSlot(val));
		}
	});
}

function twelveHour(val) {
	return val > 12 ? val - 12 : val;
}
$(function() {
	$('.available-months').on('click', 'a', function(evt) {
		evt.preventDefault();
		var monthName = $(this).attr('data-month-name');
		var month = times[monthName];
		$('.calendar-view').html('');
		
		var daysInMonth = getDaysInMonth(month.num);
		for(var i = 1; i <= daysInMonth; i++) {
			var styles = '';
			var dayInMonth = getStartDayInMonth(month.num);
			if(i == 1 && dayInMonth > 0) {
				styles = 'margin-left: ' + (dayInMonth * 14.285714286) + '%';
			}
			var classes = '';
			if(month[i]) {
				classes = 'has-slots';
			}
			$('.calendar-view').append('<div class="day ' + classes + '" ' +
					' data-month="' + month.name + '" ' +
					' data-day="' + i + '" style="' + styles +'" ><div class="vert-center">' + i + '</div></div>')
		}
		
		$('.available-times').html('Choose a day to see the available times.');
		$('.available-months a').removeClass('selected');
		$(this).addClass('selected');
	});
	
	$('.calendar-view').on('click', '.day', function(evt){
		evt.preventDefault();
		var monthName = $(this).attr('data-month');
		var dayNum = $(this).attr('data-day');
		
		var day = times[monthName][dayNum];
		if(!day) {
			$('.available-times').html('<h2>' + monthName + " " + dayNum + '</h2><p>No times are available on this day.</p>');
		}
		else {
			renderTimeSlotsInDetailView(day, monthName, dayNum);
		}
	});
});








