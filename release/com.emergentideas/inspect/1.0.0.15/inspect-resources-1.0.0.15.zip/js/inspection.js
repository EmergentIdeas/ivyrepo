window.indexedDB = window.indexedDB || window.webkitIndexedDB || window.mozIndexedDB || window.OIndexedDB || window.msIndexedDB;
IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction || window.OIDBTransaction || window.msIDBTransaction;

callForUpdate = false;

function empty(val) {
	if(typeof val === 'undefined') {
		return true;
	}
	if(val == null) {
		return true;
	}
	var v = val + '';
	if(v.trim() == '') {
		return true;
	}
	
	return false;
}

dbVersion = 5;
var request = indexedDB.open("inspect", dbVersion);
idBase = Math.floor(new Date().getTime() / 1000) % 100000000;

/**
 * Keeps a count of which long running operation we're performing. If the number is
 * different for an operation than what it started with, the operation should probably
 * stop. 
 */
operationCount = 0;

/**
 * The list of buildings that have been considered for inspection or noshow
 */
consideredBuildings = [];

function canRun(startedOperationCount) {
	if(typeof startedOperationCount == 'undefined') {
		return true;
	}
	return startedOperationCount == operationCount;
}

function newOperation() {
	operationCount += 1;
	return operationCount;
}

function upgradedb(db) {
	if(db.objectStoreNames.contains("building") == false){
	    obstore = db.createObjectStore("building", { keyPath: "id" });
	    obstore = db.createObjectStore("buildingoverlay", { keyPath: "id" });
		
	    obstore = db.createObjectStore("address", { keyPath: "id" });
	    obstore = db.createObjectStore("addressoverlay", { keyPath: "id" });
	    
	    obstore = db.createObjectStore("contact", { keyPath: "id" });
	    obstore = db.createObjectStore("contactoverlay", { keyPath: "id" });
	}
	if(db.objectStoreNames.contains("picdata") == false){
	    obstore = db.createObjectStore("picentry", { keyPath: "id" });
	    obstore = db.createObjectStore("picdata", { keyPath: "id" });
	}
	if(db.objectStoreNames.contains("inspection") == false){
	    obstore = db.createObjectStore("inspection", { keyPath: "id" });
	    obstore = db.createObjectStore("noshow", { keyPath: "id" });
	}
	if(db.objectStoreNames.contains("appointment") == false){
	    obstore = db.createObjectStore("appointment", { keyPath: "id" });
	}
}

request.onsuccess = function (event) {
    db = request.result;
    
    db.onerror = function (event) {
    	console.log("Could not open db.");
    };
    
    // check for lack of upgrade support
    if (db.setVersion) {
        if (db.version != dbVersion) {
            var setVersion = db.setVersion(dbVersion);
            setVersion.onsuccess = function () {
                upgradedb(db);
            };
        }
    }
    
    $(startup);
}
 
request.onupgradeneeded = function(event) {
	db = event.target.result;
	upgradedb(db);
}


function genId() {
	return idBase++;
}

function resetCache() {
	objCache = {};
	objCachePrimed = {};
}

resetCache();

function getTypedCache(/* String */ storeName) {
	var cache = objCache[storeName];
	if(!cache) {
		cache = {};
		objCache[storeName] = cache;
	}
	return cache;
}

function saveToCache(/* String */ storeName, /*object */ obj) {
	var cache = getTypedCache(storeName);
	cache[obj.id] = obj;
}

function fromCache(/* String */ storeName, /*integer */ id) {
	var cache = getTypedCache(storeName);
	return cache[id];
}

/* Returns an array of all the objects from the cache of the store type */
function allFromCache(/* String */ storeName) {
	var cache = getTypedCache(storeName);
	
	return _.values(cache);
}

/**
 * Convert number of bytes into human readable format
 *
 * @param integer bytes     Number of bytes to convert
 * @param integer precision Number of digits after the decimal separator
 * @return string
 */
function bytesToSize(bytes, precision)
{  
    var kilobyte = 1024;
    var megabyte = kilobyte * 1024;
    var gigabyte = megabyte * 1024;
    var terabyte = gigabyte * 1024;
   
    if ((bytes >= 0) && (bytes < kilobyte)) {
        return bytes + ' B';
 
    } else if ((bytes >= kilobyte) && (bytes < megabyte)) {
        return (bytes / kilobyte).toFixed(precision) + ' KB';
 
    } else if ((bytes >= megabyte) && (bytes < gigabyte)) {
        return (bytes / megabyte).toFixed(precision) + ' MB';
 
    } else if ((bytes >= gigabyte) && (bytes < terabyte)) {
        return (bytes / gigabyte).toFixed(precision) + ' GB';
 
    } else if (bytes >= terabyte) {
        return (bytes / terabyte).toFixed(precision) + ' TB';
 
    } else {
        return bytes + ' B';
    }
}

function primeCache(/* String */ storeName, callback, curOperationCount) {
	if(!curOperationCount) {
		curOperationCount = newOperation();
	}
	
	if(!objCachePrimed[storeName]) {
		getAllItems(storeName, function(items) {
			$.each(items, function() {
				saveToCache(storeName, this);
			});
			
			var hasOverlay = doesDatabaseHaveStore(storeName + 'overlay');
			if(hasOverlay) {
				getAllItems(storeName + 'overlay', function(items) {
					$.each(items, function() {
						saveToCache(storeName, this);
					});
					objCachePrimed[storeName] = true;
					if(callback) {
						callback();
					}
				}, curOperationCount);
			}
			else {
				objCachePrimed[storeName] = true;
				if(callback) {
					callback();
				}
			}
		}, curOperationCount);
	}
	else if(callback) {
		callback();
	}
}

function getBuildingWithLocationFromCache(/* integer */ addressId) {
	var results = [];
	$.each(allFromCache('building'), function() {
		if(this.buildingLocation == addressId) {
			results.push(this);
		}
	});
	
	if(results.length > 0) {
		return results[0];
	}
	
	return null;
}

/**
 * convert 03/16/2015 to 2015-03-16
 * @param dateString
 */
function convertDateFormat(dateString) {
	return dateString.substring(6, 10) + '-' + dataString.substring(0, 2) + '-' + dataString.substring(3, 5);
}

function consumeInspection(inspection) {
	
	inspection.inspectionRecord.buildingId = inspection.building.id;
	
	var v = null;
	if(inspection.building.ownerContact) {
		v = inspection.building.ownerContact;
		inspection.building.ownerContact = inspection.building.ownerContact.id;
		if(v.dirty && isSavable(v)) {
			saveObject('contact', v);
		}
	}
	
	if(inspection.building.ownerAddress) {
		v = inspection.building.ownerAddress;
		inspection.building.ownerAddress = inspection.building.ownerAddress.id;
		if(v.dirty && isSavable(v)) {
			saveObject('address', v);
		}
	}
	
	if(inspection.building.residentContact) {
		v = inspection.building.residentContact;
		inspection.building.residentContact = inspection.building.residentContact.id;
		if(v.dirty && isSavable(v)) {
			saveObject('contact', v);
		}
	}
	
	if(inspection.building.buildingLocation) {
		v = inspection.building.buildingLocation;
		inspection.building.buildingLocation = inspection.building.buildingLocation.id;
		if(v.dirty && isSavable(v)) {
			saveObject('address', v);
		}
	}
	
	if(inspection.building.dirty && isSavable(inspection.building)) {
		saveObject('building', inspection.building);
	}
	
	inspection.inspectionRecord.dirty = true;
	inspection.inspectionRecord.id = genId();
	
	saveObject("inspection", inspection.inspectionRecord);
}

/* an array of building objects */
function consumeListOfBuildings(buildings, curOperation) {
	if(!canRun(curOperation)) {
		console.log("cancel operation");
		return;
	}
	var trans = db.transaction(["building", "address", "contact"], "readwrite");
	var buildingStore = trans.objectStore("building");
	var addressStore = trans.objectStore("address");
	var contactStore = trans.objectStore("contact");
	
	$.each(buildings, function() {
		if(!canRun(curOperation)) {
			console.log("cancel operation");
			return false;
		}
		if(this.buildingLocation) {
			var buildingLocation = this.buildingLocation; 
			addressStore.put(buildingLocation);
			this.buildingLocation = buildingLocation.id;
		}
		if(this.ownerAddress) {
			var ownerAddress = this.ownerAddress; 
			addressStore.put(ownerAddress);
			this.ownerAddress = ownerAddress.id;
		}
		if(this.ownerContact) {
			var ownerContact = this.ownerContact; 
			contactStore.put(ownerContact);
			this.ownerContact = ownerContact.id;
		}
		if(this.residentContact) {
			var residentContact = this.residentContact; 
			contactStore.put(residentContact);
			this.residentContact = residentContact.id;
		}
		buildingStore.put(this);
	});
}

function isSavable(obj) {
	if(!obj) {
		return false;
	}
	
	if(Object.keys) {
		return Object.keys(obj).length > 0;
	}
	
	return true;
}

function resolveQuestionStatus(inspectionMemberName, status) {
	if(status == null) {
		return null;
	}
	if("roofDrain" == inspectionMemberName) {
		if(status == 'PROPER') {
			return "it is properly constructed to discharge to open air or storm system";
		}
		if(status == 'IMPROPER') {
			return "it is improperly constructed to discharge into the sanitary sewer system";
		}
		if(status == 'UNDETERMINED') {
			return "discharge location not determined";
		}
		if(status == 'DNE') {
			return "no roof drain";
		}
	}
	
	if("seepageCollection" == inspectionMemberName) {
		if(status == 'PROPER') {
			return "it is properly constructed to discharge into a sump pit";
		}
		if(status == 'IMPROPER') {
			return "it is improperly constructed to discharge into the sanitary sewer system";
		}
		if(status == 'UNDETERMINED') {
			return "discharge location not determined";
		}
		if(status == 'DNE') {
			return "no seepage collection";
		}
	}
	
	if("sump" == inspectionMemberName) {
		if(status == 'PROPER') {
			return "pump is properly plumbed to discharge outside the basement through rigid piping";
		}
		if(status == 'IMPROPER') {
			return "pump is improperly plumbed to discharge into the sanitary sewer system";
		}
		if(status == 'FLEXHOSE') {
			return "pump has the capability of discharging into the sanitary sewer system (ex. flex hose)";
		}
		if(status == 'UNDETERMINED') {
			return "discharge location not determined";
		}
		if(status == 'NO_PUMP') {
			return "there is a pit with no pump";
		}
		if(status == 'DNE') {
			return "no sump pit collection";
		}
	}
	
	if("footingDrain" == inspectionMemberName) {
		if(status == 'PROPER') {
			return "it is properly constructed to discharge to open air or storm system";
		}
		if(status == 'IMPROPER') {
			return "it is improperly constructed to discharge into the sanitary sewer system";
		}
		if(status == 'UNDETERMINED') {
			return "discharge location not determined";
		}
		if(status == 'DNE') {
			return "no footing drain";
		}
	}
	
	return null;
}

function setActiveArea(val) {
	$('#active-area').html(val);
}

function appendActiveArea(val) {
	$('#active-area').append(val);
}

function showMessagePage(msg) {
	setActiveArea('<h1>Message</h1><p>' + msg + '</p>');
}

function formToObject(formElement, dataObject) {
	var $formElement = $(formElement);
	$formElement.find('input').each(function() {
		var name = $(this).attr('name');
		if(name) {
			dataObject[name] = $(this).val();
		}
	});
	$formElement.find('textarea').each(function() {
		var name = $(this).attr('name');
		if(name) {
			dataObject[name] = $(this).val();
		}
	});
	$formElement.find('select').each(function() {
		var name = $(this).attr('name');
		if(name) {
			dataObject[name] = $(this).val();
		}
	});
	return dataObject;
}

function saveToLocalStorage(prefix, dataObject) {
	$.each(Object.keys(dataObject), function() {
		localStorage.setItem(prefix + '.' + this, JSON.stringify(dataObject[this]));
	});
	return dataObject;
}

function getFromLocalStorage(prefix, dataObject) {
	$.each(Object.keys(dataObject), function() {
		dataObject[this] = JSON.parse(localStorage.getItem(prefix + '.' + this));
	});
	return dataObject;
}

function saveUserInfo(userInfo) {
	saveToLocalStorage('userInfo', userInfo);
}

function getUserInfo() {
	return getFromLocalStorage('userInfo', new UserInfo());
}

function ajaxErrorHandler(evt) {
	var resp = evt.responseText;
	if(resp) {
		resp = resp.trim();
	}
	if(evt.status == 409) {
		if(resp && resp == 'auth failed') {
			setActiveArea(authError())
			return;
		}
	}
	if(evt.status == 0) {
		setActiveArea(serverUnreachableError())
		return;
	}
	
	setActiveArea(unknownAPIError());
}

function isPasswordValid(userId, password, yesCallback, noCallback, noConnectionCallback) {
	$.ajax('/api/v1/password-test', {
		cache: false,
		beforeSend: function(xhr) {xhr.setRequestHeader("Authorization", "Basic " + btoa(userId + ":" + password));}
	}).fail(function(evt) {
		var resp = evt.responseText;
		if(resp) {
			resp = resp.trim();
		}
		if(evt.status == 409) {
			if(resp && resp == 'auth failed') {
				if(noCallback) {
					noCallback();
				}
				return;
			}
		}
		if(evt.status == 0) {
			if(noConnectionCallback) {
				noConnectionCallback();
			}
			return;
		}
		if(noCallback) {
			noCallback();
		}
	})
	.done(function(data) {
		if(data && typeof data == 'string') {
			data = data.trim();
		}
		if('yep' === data) {
			if(yesCallback) {
				yesCallback();
			}
		}
		else {
			if(noCallback) {
				noCallback();
			}
		}
	});

}

function getIfConnected(url, callback) {
	$.ajax('/api/v1/connection-test', {
		cache: false,
		beforeSend: authHeaderFunction
	}).fail(function(evt) {
			var resp = evt.responseText;
			if(resp) {
				resp = resp.trim();
			}
			if(evt.status == 409) {
				if(resp && resp == 'auth failed') {
					setActiveArea(authError())
					return;
				}
			}
			if(evt.status == 0) {
				setActiveArea(notConnectedMessage())
				return;
			}
			
			setActiveArea(unknownAPIError());
	})
	.done(function(data) {
		$.ajax(url, {
			cache: false,
			beforeSend: authHeaderFunction
		}).fail(ajaxErrorHandler)
		.done(callback);
	});

}

function doIfConnected(callback, unconnectedCallback) {
	$.ajax('/api/v1/connection-test', {
		cache: false,
		beforeSend: authHeaderFunction
	}).fail(function(evt) {
			var resp = evt.responseText;
			if(resp) {
				resp = resp.trim();
			}
			if(evt.status == 409) {
				if(resp && resp == 'auth failed') {
					if(unconnectedCallback) {
						unconnectedCallback(evt);
					}
					return;
				}
			}
			if(evt.status == 0) {
				if(unconnectedCallback) {
					unconnectedCallback(evt);
				}
				return;
			}
			if(unconnectedCallback) {
				unconnectedCallback(evt);
			}
	})
	.done(function(data) {
		callback(data);
	});

}

// data access classes

/**
 * Returns all items with a callback for each item.
 */
function getItems(storeName, callback, curOperationCount, allDoneCallback) {
	var objectStore = db.transaction([storeName]).objectStore(storeName);
	objectStore.openCursor().onsuccess = function(event) {
		var cursor = event.target.result;
		if(!canRun(curOperationCount)) {
			console.log("No more getting items. We are on to a new operation.")
			return;
		}
		if (cursor) {
			callback(cursor.value);
			cursor.continue();
		}
		else {
			if(typeof allDoneCallback == 'function') {
				allDoneCallback();
			}
		}
	};
}

/**
 * Returns all items with a callback at the end with the list
 */
function getAllItems(storeName, callback, curOperationCount) {
	var objectStore = db.transaction([storeName]).objectStore(storeName);
	var all = [];
	objectStore.openCursor().onsuccess = function(event) {
		var cursor = event.target.result;
		if(!canRun(curOperationCount)) {
			console.log("No more getting items. We are on to a new operation.")
			return;
		}
		if (cursor) {
			all.push(cursor.value);
			cursor.continue();
		}
		else {
			callback(all);
		}
	};
}

function getAllMap(storeName, callback, curOperationCount, idMemberName) {
	if(!idMemberName) {
		idMemberName = 'id';
	}
	var objectStore = db.transaction([storeName]).objectStore(storeName);
	var all = {};
	objectStore.openCursor().onsuccess = function(event) {
		var cursor = event.target.result;
		if(!canRun(curOperationCount)) {
			console.log("No more getting items. We are on to a new operation.")
			return;
		}
		if (cursor) {
			all[cursor.value[idMemberName]] = cursor.value;
			cursor.continue();
		}
		else {
			callback(all);
		}
	};
}



function getSaveStoreName(storeName) {
	if(storeName.indexOf('overlay') >= 0) {
		return storeName;
	}
	if(storeName.indexOf('address') == 0) {
		return 'addressoverlay';
	}
	if(storeName.indexOf('contact') == 0) {
		return 'contactoverlay';
	}
	if(storeName.indexOf('building') == 0) {
		return 'buildingoverlay';
	}
	
	return storeName;
}

/** 
 * saves an object in the overlay store
 * @param storeName
 * @param obj
 */
function saveObject(storeName, obj) {
	var actualStore = getSaveStoreName(storeName);
	var objectStore = db.transaction([actualStore], "readwrite").objectStore(actualStore);
	objectStore.put(obj);
	saveToCache(storeName, obj);
}

function deleteAll(storeName, callback, curOperationCount) {
	var actualStore = storeName;
	getAllItems(actualStore, function(items) {
		$.each(items, function() {
			deleteObject(storeName, this.id);
		});
		if(callback) {
			callback();
		}
	}, curOperationCount);
}


function syncObject(storeName, obj) {
	if(storeName == 'inspection' || storeName == 'noshow') {
		var trans = db.transaction([storeName], "readwrite");
		obj.dirty = false;
		obj.id = obj.clientId;
		var objectStore = trans.objectStore(storeName);
		objectStore.put(obj);
		saveToCache(storeName, obj);
	}
	else {
		var trans = db.transaction([storeName, storeName + 'overlay'], "readwrite");
		var objectStore = trans.objectStore(storeName);
		objectStore.put(obj);
		saveToCache(storeName, obj);
		objectStore = trans.objectStore(storeName + 'overlay');
		objectStore.delete(obj.id);
	}
}

function doesDatabaseHaveStore(storeName) {
	var hasIt = false;
	$.each(db.objectStoreNames, function() {
		if(storeName == (this + '')) {
			hasIt = true;
			return false;
		}
	});
	return hasIt;
}

function getObject(storeName, id, callback) {
	if(typeof id === 'undefined' || !id) {
		callback(null);
		return;
	}
	if(typeof id === 'string') {
		id = parseInt(id);
	}
	else if(typeof id === 'object') {
		id = parseInt(id.toString());
	}
	if(typeof id === 'undefined' || !id) {
		callback(null);
		return;
	}
	
	var hasOverlay = doesDatabaseHaveStore(storeName + 'overlay');
	
	var trans;
	if(hasOverlay) {
		trans = db.transaction([storeName, storeName + 'overlay']);
		var objectStore = trans.objectStore(storeName + 'overlay');
		objectStore.get(id).onsuccess = function (event) {
		    var val = event.target.result;
		    if(val) {
		    	callback(val);
		    }
		    else {
			    var orgStore = trans.objectStore(storeName);
			    orgStore.get(id).onsuccess = function(event) {
			    	var orgVal = event.target.result;
			    		callback(orgVal);
			    }
		    }
		}
	}
	else {
		trans = db.transaction([storeName]);
		var objectStore = trans.objectStore(storeName);
		objectStore.get(id).onsuccess = function (event) {
		    var val = event.target.result;
		    callback(val);
		}
	}
}

function getAddress(id, callback) {
	getObject("address", id, callback);
}

function saveAddress(address) {
	saveObject("address", address);
}

function getContact(id, callback) {
	getObject("contact", id, callback);
}

function saveContact(contact) {
	saveObject("contact", contact);
}

function getBuilding(id, callback) {
	getObject("building", id, function(building){
		callback(building);
	});
}

function getInspectionsForBuilding(buildingId, callback) {
	getAllItems("inspection", function(inspections) {
		var forBuilding = [];
		$.each(inspections, function() {
			if(this.buildingId == buildingId) {
				forBuilding.push(this);
			}
		});
		
		_.sortBy(forBuilding, function(inspection) {
			return inspection.inspectionDate;
		});
		callback(forBuilding);
	});
}


function saveBuilding(building) {
	saveObject("building", building);
}


function getCompleteBuilding(id, callback) {
	getObject("building", id, function(building){
		getAddress(building.buildingLocation, function(address) {
			address = address || {};
			building.buildingLocation = address;
			getAddress(building.ownerAddress, function(address) {
				address = address || {};
				building.ownerAddress = address;
				getContact(building.ownerContact, function(contact) {
					contact = contact || {};
					building.ownerContact = contact;
					getContact(building.residentContact, function(contact) {
						contact = contact || {};
						building.residentContact = contact;
						callback(building);
					});
				});
			});
		});
	});
}

function calculatePicDataImageSize(/* picdata object*/ picdata) {
	var index = picdata.data.indexOf(',');
	var clipped = picdata.data.substring(index + 1);
	var dat = atob(clipped);
	return dat.length;
}
function calculatePictureSizes(callback, curOperationCount, ids) {
	if(!curOperationCount) {
		curOperationCount = newOperation();
	}
	getAllItems("picdata", function(pics) {
		
		var sizes = {};
		
		$.each(pics, function() {
			var size = {
					fileId: this.id
			}
			sizes[this.id] = size;
			
			size.fileSize = calculatePicDataImageSize(this);
		});
		callback(sizes);
	}, curOperationCount)
}


//function saveNote(note) {
//	var objectStore = db.transaction(["notes"], "readwrite").objectStore("notes");
//	if(note.id) {
//		objectStore.put(note, note.id);
//	}
//	else {
//		note.id = genId() + '';
//		objectStore.put(note, note.id);
//	}
//}

function deleteObject(dataType, id) {
	var objectStore = db.transaction([dataType], "readwrite").objectStore(dataType);
	objectStore.delete(id);
}

function showAllBuildings() {
	var $active = $('#active-area');
	var curCount = newOperation();
	$active.empty();
	getItems("building", function(building) {
		getAddress(building.buildingLocation, function(address) {
			if(!canRun(curCount)) return;
			$active.append('<a href="#building/' + building.id + '" class="building-link" data-id="' + building.id + 
					'">buildingId=' + building.id + ', ' + displayAddressLinear(address) + "</a><br/>");
		});
	}, curCount);
}

function authHeaderFunction(xhr) {
	var userInfo = getUserInfo();
	xhr.setRequestHeader("Authorization", "Basic " + btoa(userInfo.userId + ":" + userInfo.password));
}
function fetchBuildings() {
	var curCount = newOperation();
	clearForMessages();
	resetCache();
	$('#active-area').append("<p>Fetching data from server.</p>");
	getIfConnected('/api/v1/building/all', function(data) {
		clearForMessages();
		$('#active-area').append("<p>Saving data locally.</p>");
		consumeListOfBuildings(data, curCount);
		$('#active-area').append("<p>Done saving data.</p>");
	});
	
}

function fetchAppointments(curCount, callback) {
	if(typeof curCount == 'undefined') {
		curCount = newOperation();
	}
	$('#active-area').append("<p>Fetching appointments from server.</p>");
	getIfConnected('/api/v1/inspection-appointments/all', function(data) {
		$('#active-area').append("<p>Saving data locally.</p>");
		deleteAll('appointment', function() {
			$.each(data, function() {
				if(this.start) {
					this.start = new Date(this.start);
				}
				if(this.end) {
					this.end = new Date(this.end);
				}
				saveObject('appointment', this);
			});
			if(callback) {
				callback();
			}
		});
		$('#active-area').append("<p>Done saving appointments.</p>");
	});
}

function fetchNeededImages(curOperation) {
	if(!curOperation) {
		curOperation = newOperation();
	}
	getIfConnected('/api/v1/needed-images', function(images) {
		getAllItems('picentry', function(entries) {
			var filenames = _.pluck(entries, 'dataFilename');
			var neededFilenames = _.pluck(images, 'imgName');
			
			var filenamesToDownload = _.difference(neededFilenames, filenames);
			var imagesToDownload = _.filter(images, function(img) {
				return _.contains(filenamesToDownload, img.imgName);
			});
			fetchPicturesFromServer(imagesToDownload, curOperation);
		}, curOperation);			
	});
	resetCache();
}

function fetchPicturesFromServer(picList, curOperation) {
	if(!curOperation) {
		curOperation = newOperation();
	}

	var next = null;
	if(picList.length > 0) {
		next = picList.shift();
	}

	if(next) {
		var url = '/api/v1/tablet-image/' + next.imgName; 
		appendActiveArea(p('Downloading historical image ' + next.imgName));
		if(canRun(curOperation)) {
			$.ajax(url, {
				cache: false,
				beforeSend: authHeaderFunction
			}).fail(ajaxErrorHandler)
			.done(function(data) {
				var validFile = true;
				if(typeof data == 'string' && data.indexOf('<html') > -1) {
					validFile = false;
				}
				if(validFile) {
					var val = 'data:';
					var mediaType = '';
					if(/png$/i.exec(next.imgName)) {
						val += 'image/png;base64';
						mediaType = 'image/png';
					}
					
					if(/jpg$/i.exec(next.imgName)) {
						val += 'image/jpeg;base64';
						mediaType = 'image/jpeg';
					}
					val += ',';
					val += data;
					
					var picentry = {
						dataFilename: next.imgName,
						id: genId(),
						mimeType: mediaType,
						dirty: false,
						keepTill: new Date(next.keepTill)
					};
					
					saveObject('picentry', picentry);
					
					var picdata = {
						id: picentry.id,
						data: val
					}
					
					saveObject('picdata', picdata);
					appendActiveArea(p('Stored image ' + next.imgName));
				}
				else {
					appendActiveArea(p('Content for ' + next.imgName + ' does not look right. Not storing it.'));
				}
				if(canRun(curOperation)) {
					fetchPicturesFromServer(picList, curOperation);
				}
			});
		}
	}
	else {
		appendActiveArea('<p>Done downloading inspection pictures</p>');
	}
}

function fetchPastInspections(curCount, callback) {
	if(typeof curCount == 'undefined') {
		curCount = newOperation();
	}

	appendActiveArea(p('Determining which inspections we have already.'));
	var inspectionIds = [];
	getAllItems('inspection', function(inspections) {
		inspectionIds = _.pluck(inspections, 'id');
		appendActiveArea(p('Fetching list of past inspections from server.'));
		
		getIfConnected('/api/v1/past-inspections/ids', function(inspectionsOnServerIds) {
			var fetchableIds = _.difference(inspectionsOnServerIds, inspectionIds);
			if(fetchableIds.length > 0) {
				appendActiveArea(p('Need to fetch ' + fetchableIds.length + ' past inspections.'));
				var idsString = '';
				$.each(fetchableIds, function(id) {
					idsString += ',' + this;
				});
				idsString = idsString.substring(1);
				var url = '/api/v1/past-inspections/inspection';
				$.ajax(url, {
					cache: false,
					method: 'POST',
					beforeSend: authHeaderFunction,
					data: {
						ids: idsString
					}
				}).fail(ajaxErrorHandler)
				.done(function(data) {
					appendActiveArea(p('Downloaded inspections. Saving locally.'));
					$.each(data, function() {
						if(_.contains(inspectionIds, this.id) == false) {
							saveObject('inspection', this);
						}
					});
					appendActiveArea(p('All inspections saved.'));
					if(callback) {
						callback();
					}
				});
			}
			else {
				appendActiveArea(p('All past inspections already fetched.'));
				if(callback) {
					callback();
				}
			}

		});
	}, curCount);
	
	
}




function postDataAsBody(url, dataObj, doneCallback) {
	var dat = JSON.stringify(dataObj);
	if(dat.indexOf('[') != 0) {
		dat = '[' + dat + ']';
	}

	$.ajax(url, {
		cache: false,
		method: 'POST',
		beforeSend: authHeaderFunction,
		data: dat,
		processData: false
	}).fail(ajaxErrorHandler)
	.done(function(data) {
		if(typeof doneCallback == 'function') {
			doneCallback(data);
		}
	});

}

/**
 * If serverSizeTable and localSizeTable are present we can assume we're supposed to do an aggressive
 * sync and push anything that the server doesn't report.
 * @param picList
 * @param curOperation
 * @param serverSizeTable
 */
function syncPicList(picList, curOperation, serverSizeTable, localSizeTable, doneCallback) {
	if(!curOperation) {
		curOperation = newOperation();
	}

	var next = null;
	while(picList.length > 0) {
		next = picList.shift();
		if(next.dirty) {
			break;
		}
		if(serverSizeTable) {
			if(!serverSizeTable[next.id]) {
				break;
			}
		}
		next = null;
	}

	if(next) {
		if(canRun(curOperation)) {
			getObject('picdata', next.id, function(data) {
				var composite = _.extend({}, next, data);
				appendActiveArea(pushingPhoto(next));
				postDataAsBody('/api/v1/save-picture', composite, function(response) {
					if(response.trim() == 'yep') {
						next.dirty = false;
						saveObject("picentry", next);
					}
					if(canRun(curOperation)) {
						syncPicList(picList, curOperation, serverSizeTable, localSizeTable, doneCallback);
					}
				});
			});
		}
	}
	else {
		appendActiveArea('<p>Done syncing pictures</p>');
		if(doneCallback) {
			doneCallback();
		}
	}
}

function syncPics(curOperation, callback) {
	appendActiveArea("<p>Syncing photos</p>");
	getAllItems('picentry', function(entries) {
		syncPicList(entries, curOperation, null, null, callback);
	}, curOperation);
}

function aggressiveSyncPics(curOperation) {
	appendActiveArea("<p>Aggressively syncing photos</p>");
	getIfConnected("/api/v1/picture/sizes", function(serverSizeTable) {
		calculatePictureSizes(function(localSizeTable) {
			getAllItems('picentry', function(entries) {
				syncPicList(entries, curOperation, serverSizeTable, localSizeTable);
			}, curOperation);
		}, curOperation);
	});
}


function clearForMessages() {
	setActiveArea('<br/>');
}

function convertObjectsToIds(building) {
	if(building.buildingLocation && typeof building.buildingLocation == 'object') {
		building.buildingLocation = building.buildingLocation.id;
	}
	if(building.ownerAddress && typeof building.ownerAddress == 'object') {
		building.ownerAddress = building.ownerAddress.id;
	}
	if(building.ownerContact && typeof building.ownerContact == 'object') {
		building.ownerContact = building.ownerContact.id;
	}
	if(building.residentContact && typeof building.residentContact == 'object') {
		building.residentContact = building.residentContact.id;
	}
	
	return building;
}

function keepDirty(list) {
	var cleansed = [];
	var dirtyObjs = _.filter(list, function(val) {
		return val.dirty;
	});
	
	$.each(dirtyObjs, function() {
		var dupe = _.clone(this);
		delete dupe.buildingLocation;
		delete dupe.ownerAddress;
		delete dupe.ownerContact;
		delete dupe.residentContact
		cleansed.push(dupe);
	});
	
	return cleansed;
}

function pictureSizeReport() {
	setActiveArea('');
	calculatePictureSizes(function(sizeMap) {
		var summary = {
			count: 0,
			size: 0
		};
		_.each(_.keys(sizeMap), function(key) {
			summary.count++;
			summary.size += sizeMap[key].fileSize;
		});
		
		appendActiveArea(pictureSizeReportTemplate(summary));
	});
}

function deleteSavedPictures(curOperation, callback) {
	appendActiveArea('<p>Checking server to make sure we will not delete anything not yet saved.</p>');
	
	if(!curOperation) {
		curOperation = newOperation();
	}
	var curDate = new Date();
	getAllMap("picentry", function(entriesMap) {
		calculatePictureSizes(function(localSizeMap) {
			getIfConnected('/api/v1/picture/sizes', function(serverSizeMap) {
				var picsDeleted = 0;
				_.each(_.keys(localSizeMap), function(key) {
					var localEntry = entriesMap[key];
					if(localEntry.keepTill && !localEntry.dirty) {
						// indicates we've got something just for inspections.
						if(localEntry.keepTill.getTime() < curDate.getTime()) {
							deleteObject('picdata', parseInt(key));
							deleteObject('picentry', parseInt(key));
							picsDeleted++;
						}
					}
					else {
						var localSize = localSizeMap[key].fileSize;
						if(!serverSizeMap[key]) {
							appendActiveArea('<p>Could not delete image with id ' + key + ' because the server has no record of it.</p>');
						}
						else {
							if(serverSizeMap[key].fileSize == localSizeMap[key].fileSize) {
								if(entriesMap[key].dirty) {
									appendActiveArea('<p>Could not delete image with id ' + key + ' because it is has not been synced with the server.</p>');
								}
								else {
									deleteObject('picdata', parseInt(key));
									deleteObject('picentry', parseInt(key));
									picsDeleted++;
								}
							}
							else {
								appendActiveArea('<p>Could not delete image with id ' + key + ' because the server reports it as a different size, ' 
										+ serverSizeMap[key].fileSize + ' vs ' + localSizeMap[key].fileSize + ' for local.</p>');
							}
						}
					}
				});
				
				appendActiveArea('<p>Done deleting ' + picsDeleted + ' pictures.</p>');
				if(callback) {
					callback();
				}
			});
		}, curOperation);
	}, curOperation, 'id');
}

function resolveImages(currentOperation) {
	primeCache('picentry', function() {
		var allPicEntries = allFromCache('picentry');
		$('#active-area .resolvable-image').each(function() {
			var $resolvable = $(this);
			var imageName = $resolvable.attr('data-image-name');
			var entry = _.find(allPicEntries, function(item) {
				return item.dataFilename == imageName || item.id == imageName || (item.dataFilename && item.dataFilename.indexOf(imageName) == 0); 
			});
			if(entry) {
				getObject('picdata', entry.id, function(picdata) {
					$resolvable.html(resolvedImage(picdata.data));
				});
			}
		});
	}, currentOperation);
}



function syncAddresses() {
	syncType("address");
}
function syncType(type, curOperation, callback) {
	if(!curOperation) {
		curOperation = newOperation();
	}
	
	var storeName = type;
	var hasOverlay = doesDatabaseHaveStore(storeName + 'overlay');
	if(hasOverlay) {
		storeName += 'overlay';
	}
	appendActiveArea("<p>" + type + ": Finding objects that need to sync.</p>");
	getAllItems(storeName, function(objects) {
		if(objects.length == 0) {
			appendActiveArea("<p>" + type + ": None to sync.</p>");
			if(callback) {
				callback();
			}
			return;
		}
		objects = keepDirty(objects);
		if(objects.length == 0) {
			appendActiveArea("<p>" + type + ": None to sync.</p>");
			if(callback) {
				callback();
			}
			return;
		}
		postDataAsBody('/api/v1/' + type + '/sync', objects, function(data) {
			appendActiveArea("<p>" + type + ": Updating local store</p>");
			$.each(data, function() {
				syncObject(type, convertObjectsToIds(this));
			});
			appendActiveArea("<p>" + type + ": Synced</p>");
			if(callback) {
				callback();
			}
		});
	}, curOperation);
}



function createSyncStatus(dataType, callback, curOperationCount) {
	var status = {
			total: 0,
			dirty: 0
	};
	
	var storeName = getSaveStoreName(dataType);
	var trans = db.transaction([storeName], "readwrite");
	var objectStore = trans.objectStore(storeName);
	objectStore.openCursor().onsuccess = function(event) {
		var cursor = event.target.result;
		if(!canRun(curOperationCount)) {
			console.log("No more getting status. We are on to a new operation.")
			return;
		}
		if (cursor) {
			status.total++;
			if(cursor.value.dirty) {
				status.dirty++;
			}
			cursor.continue();
		}
		else {
			callback(status);
		}
	};
}

function getExtensionForMime(mimeType) {
	if(mimeType == 'image/png') {
		return '.png';
	}
	else if(mimeType == 'image/jpeg') {
		return '.jpg';
	}
	
	return '';
}
function savePicture(id, data, mimeType, fileName) {
	if(!fileName) {
		fileName = '' + id + getExtensionForMime(mimeType);
	}
	var picentry = {
			id: id,
			dataFilename: fileName,
			mimeType: mimeType,
			dirty: true
		};
	var picdata = {
		id: id,
		data: data
	};
	saveObject("picentry", picentry);
	saveObject("picdata", picdata);
	return [picentry, picdata];
}

function loadPicture(id, callback) {
	getObject('picentry', id, function(picentry) {
		getObject('picdata', id, function(picdata) {
			callback([picentry, picdata]);
		});
	});
}

function getPicIdForName(name, callback) {
	primeCache('picentry', function() {
		var target = _.find(allFromCache('picentry'), function(item) {
			return item.dataFilename == name; 
		});
		if(target) {
			callback(target.id);
		}
		else {
			callback(null);
		}
	});
}
/**
 * duplicates a picture with the given name and returns an array of the picentry and picdata
 * objects
 * @param name The name of pic to duplicate
 */
function duplicatePicture(name, callback) {
	getPicIdForName(name, function(id) {
		if(id) {
			loadPicture(id, function(items) {
				var newId = genId();
				items[0].id = newId;
				items[1].id = newId;
				saveObject('picentry', items[0]);
				saveObject('picdata', items[1]);
				callback(items);
			});
		}
		else {
			callback(null);
		}
	});
}

function displayInspectionInArea(id, curOp) {
	if(!curOp) {
		curOp = newOperation();
	}
	getObject('inspection', id, function(inspection) {
		inspection.residentSignature = inspection.residentSignature || inspection.residentSig; 
		inspection.inspectorSignature = inspection.inspectorSignature || inspection.inspectorSig;
		inspection.pictureNames = inspection.pictureNames || inspection.pictures;
		appendActiveArea(displayInspection(inspection));
		resolveImages(curOp);
	}, curOp);
	
}

function configureRouting() {
	if(!hasher.getPreviousHash) {
		hasher.getPreviousHash = function() {
			return hasher.previousHash || location.hash;
		}
	}
	crossroads.addRoute('home', function() {
		newOperation();
		if(typeof inspectWidget != 'undefined') {
			inspectWidget.goToConfirmation();
			hasher.setHash('confirm');
			return;
		}
		var userInfo = getUserInfo();
		if(empty(userInfo.userId) || empty(userInfo.password) || empty(userInfo.inspectorName)) {
			setActiveArea(userInfoControlPanel());
		}
		else {
			setActiveArea(controlPanel());
		}
	});
	crossroads.addRoute('confirm', function() {
	});
	crossroads.addRoute('cancel', function() {
	});
	crossroads.addRoute('message', function() {
	});
	crossroads.addRoute('sync-status', function() {
		var op = newOperation();
		$('#active-area').html(syncStatus());
		$.each(['address', 'contact', 'building', 'picentry', 'noshow', 'inspection'], function() {
			var group = '.' + this;
			createSyncStatus(this, function(status) {
				$(group + ' .dirty').html(status.dirty);
				$(group + ' .total').html(status.total);
			}, op)
		});
	});
	crossroads.addRoute('clear-caches', function() {
		newOperation();
		resetCache();
		showMessagePage('<p>Caches cleared.</p>');
	});
	crossroads.addRoute('all-buildings', function() {
		newOperation();
		showAllBuildings();
	});
	crossroads.addRoute('search-buildings', function() {
		newOperation();
		
		var searchBuildingsWidget = new SearchBuildingsWidget();
		setActiveArea(searchBuildingsWidget.el);
		searchBuildingsWidget.render();

	});
	crossroads.addRoute('building/{id}', function(id) {
		if(typeof inspectWidget != 'undefined') {
			inspectWidget.goToConfirmation();
			hasher.setHash('confirm');
			return;
		}
		newOperation();
		getCompleteBuilding(id, function(building) {
			$('#active-area').empty().append(displayBuilding(building));
			getInspectionsForBuilding(id, function(inspections) {
				_.each(inspections, function(inspection) {
					inspection.building = building;
					$('.past-inspections').append(displayPastInspectionLink(inspection))
				});
			});
		});
	});
	crossroads.addRoute('inspection/{id}', function(id) {
		if(typeof inspectWidget != 'undefined') {
			inspectWidget.goToConfirmation();
			hasher.setHash('confirm');
			return;
		}
		var curOp = newOperation();
		setActiveArea('');
		displayInspectionInArea(id, curOp);
	});
	crossroads.addRoute('appointment/{id}', function(id) {
		if(typeof inspectWidget != 'undefined') {
			inspectWidget.goToConfirmation();
			hasher.setHash('confirm');
			return;
		}
		var curOp = newOperation();
		getObject('appointment', id, function(appointment) {
			getCompleteBuilding(appointment.buildingId, function(building) {
				building.appointmentId = id;
				$('#active-area').empty().append(displayBuilding(building));
			});
		}, curOp);
	});
	crossroads.addRoute('appointment/{id}/no-show', function(id) {
		newOperation();
		if(confirm('Mark appointment as no show?')) {
			var noshow = {
					appointmentId: id,
					id: genId(),
					dirty: true
			}
			saveObject('noshow', noshow);
			showMessagePage('Appointment marked as no show.');
			hasher.setHash('message');
			getObject('appointment', id, function(appt) {
				consideredBuildings.push(appt.buildingId);
			});
		}
	});
	crossroads.addRoute('building/{id}/inspect', function(id) {
		newOperation();
		consideredBuildings.push(id);
		getCompleteBuilding(id, function(building) {
			getInspectionsForBuilding(id, function(inspections) {
				var inspectionRecord = new InspectionRecord();
				var last = null;
				if(inspections && inspections.length > 0) {
					last = inspections[inspections.length -1];
				}
				
				var createInspection = function() {
					var currentInspection = {building: building, inspectionRecord: inspectionRecord};
					inspectWidget = new BuildingInspectionWidget({ inspection: currentInspection});
					setActiveArea(inspectWidget.el);
					inspectWidget.render();
				};
				
				if(last) {
					var lastInfo = _.pick(last, 'comments', 'footingDrain', 'inspectionResult',
							'roofDrain', 'seepageCollection', 'sump', 'violationFixByDate');
					_.extend(inspectionRecord, lastInfo);
				}
				if(last && last.diagram) {
					duplicatePicture(last.diagram, function(items) {
						if(items) {
							inspectionRecord.diagram = items[0].id;
						}
						createInspection();
					});
				}
				else {
					createInspection();
				}
				
			});
		});
	});
	crossroads.addRoute('address/{id}', function(id) {
		newOperation();
		getAddress(id, function(address) {
			var addr = new EditAddressWidget({returnTo: hasher.getPreviousHash(), address: address});
			var result = addr.render();
			$('#active-area').empty().append(addr.el);
		});
	});
	crossroads.addRoute('fetch-buildings', function() {
		fetchBuildings();
	});
	crossroads.addRoute('pick-day', function() {
		if(typeof inspectWidget != 'undefined') {
			inspectWidget.goToConfirmation();
			hasher.setHash('confirm');
			return;
		}
		setActiveArea('<p>Loading appointments. One moment please...</p>');
		var curOp = newOperation();
		primeCache('building', function() {
			primeCache('address', function() {
				primeCache('appointment', function() {
					var w = new PickDayToInspect();
					w.render();
					setActiveArea(w.el);
				}, curOp);
			}, curOp);
		}, curOp);
	});
	crossroads.addRoute('fetch-appointments', function() {
		resetCache();
		clearForMessages();
		fetchAppointments();
	});
	crossroads.addRoute('fetch-past-inspections', function() {
		clearForMessages();
		fetchPastInspections();
	});
	crossroads.addRoute('sync-addresses', function() {
		resetCache();
		syncAddresses();
	});
	crossroads.addRoute('picture-size-report', function() {
		pictureSizeReport();
	});
	crossroads.addRoute('sync-all', function() {
		var curOp = newOperation();
		clearForMessages();
		resetCache();
		
		fetchAppointments(curOp, function() {
			syncType('inspection', curOp, function() {
				syncType('address', curOp, function() {
					syncType('contact', curOp, function() {
						syncType('building', curOp, function() {
							syncType('noshow', curOp, function() {
								syncPics(curOp, function() {
									deleteSavedPictures(curOp, function() {
										fetchPastInspections(curOp, function() {
											appendActiveArea(p('Fetching images from server to prime reinspections.'));
											fetchNeededImages(curOp);
										});
									});
								});
							});
						});
					});
				});
			});
		});
	});
	crossroads.addRoute('sync-pics', function() {
		clearForMessages();
		syncPics(newOperation());
	});
	crossroads.addRoute('aggressize-sync-pics', function() {
		clearForMessages();
		aggressiveSyncPics(newOperation());
	});
	crossroads.addRoute('user-info', function() {
		var userInfoWidget = new EditUserInfoWidget();
		userInfoWidget.render();
	});
	crossroads.addRoute('delete-unneeded-pics', function() {
		setActiveArea('<h1>Deleting Saved Pictures</h1>');
		deleteSavedPictures();
	});
	crossroads.addRoute('show-pics', function() {
		clearForMessages()
		appendActiveArea(showPics());
		getItems("picentry", function(entry) {
			$('.pics').append(showPicLink(entry));
		});
	});
	crossroads.addRoute('show-pic/{id}', function(id) {
		
		getObject("picentry", id, function(entry) {
			getObject("picdata", id, function(data) {
				var composite = _.extend({}, entry, data);
				clearForMessages()
				appendActiveArea(showPic(composite));
			});
		});
	});
	crossroads.addRoute('fetch-needed-images', function() {
		clearForMessages()
		appendActiveArea(p('Fetching images from server to prime reinspections.'));
		fetchNeededImages(newOperation());
	});
	crossroads.addRoute('pic-test', function() {
		var pictest = new PicCapture({
			picList: []
		});
		setActiveArea(pictest.el);
		pictest.render();
	});
	crossroads.addRoute('update-app-version', function() {
		callForUpdate = true;
		doIfConnected(function() {
			resetCache();
			showMessagePage('The app will be updated in one second.');
			setTimeout(function() {
				window.applicationCache.update();
			}, 1000);
			
		}, function() {
			showMessagePage('The server could not be reached so the app will not be updated.');
		});
	});
	
	crossroads.addRoute('control-panel', function() {
		$('#active-area').empty().append(controlPanel());
	});
	
	crossroads.addRoute('all-addresses', function() {
		var $active = $('#active-area');
		$active.empty();
		getItems("address", function(address) {
			$active.append(displayAddressLinear(address) + "<br/>");
		});
	});
	
	crossroads.routed.add(console.log, console); //log all routes
	 
	//setup hasher
	function parseHash(newHash, oldHash){
	  crossroads.parse(newHash);
	  hasher.previousHash = oldHash;
	}
	hasher.initialized.add(parseHash); //parse initial hash
	hasher.changed.add(parseHash); //parse hash changes
	hasher.init(); //start listening for history change
	setActiveArea(controlPanel());
}

// notes handlers
function startup() {
	configureRouting();
	
	$('#active-area').on('click', '.note-summary .delete', function(evt) {
		evt.preventDefault();
		var $noteSummary = $(this).closest('.note-summary');
		var id = $noteSummary.attr('data-id');
		deleteNote(id);
		$noteSummary.remove();
	});

	$('#active-area').on('click', '.note-summary .sync', function(evt) {
		evt.preventDefault();
		var $noteSummary = $(this).closest('.note-summary');
		var id = $noteSummary.attr('data-id');
		
		loadNote(id, function(note) {
			note.dirty = false;
			saveNote(note);
			$noteSummary.replaceWith(noteSummary(note));
		});
	});

	$('#active-area').on('submit', '.note-edit-form', function(evt) {
		evt.preventDefault();
		var v = $('.note-edit-form').serializeArray();
		
		var obj = {};
		$.each(v, function() {
			obj[this.name] = this.value;
		});
		obj.dirty = true;
		saveNote(obj);
	});
	
	function onUpdateReady() {
		try {
			window.location = '/inspection.html';
		}
		catch(e) {}
		clearForMessages();
		appendActiveArea("<p>Application updated.</p>");
	}
	window.applicationCache.addEventListener('updateready', onUpdateReady);
	if(window.applicationCache.status === window.applicationCache.UPDATEREADY) {
		callForUpdate = false;
		onUpdateReady();
	}
	window.applicationCache.addEventListener('noupdate', function() {
		if(callForUpdate) {
			clearForMessages();
			appendActiveArea("<p>Application already at latest version.</p>");
			callForUpdate = false;
		}
	});
	console.log("ran start up script");
}


CKEDITOR.disableAutoInline = true;
CKEDITOR.config.extraPlugins = '';
CKEDITOR.config.allowedContent = true;
CKEDITOR.config.disableNativeSpellChecker = false;
CKEDITOR.config.filebrowserBrowseUrl = null;
CKEDITOR.config.filebrowserImageBrowseUrl = null;
CKEDITOR.config.filebrowserUploadUrl = null;


