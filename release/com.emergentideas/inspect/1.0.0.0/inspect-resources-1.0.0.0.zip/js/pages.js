
allMonthNames = [
         	    "January", "February", "March",
        	    "April", "May", "June",
        	    "July", "August", "September",
        	    "October", "November", "December"
        	]; 

function getMonthNameFromDate(d) {
	return allMonthNames[d.getMonth()];
}

function getShortMonthNameFromDate(d) {
	return getMonthNameFromDate(d).substr(0, 3);
}
/*
if(!Date.prototype.monthNames) {
	Date.prototype.monthNames = [
	    "January", "February", "March",
	    "April", "May", "June",
	    "July", "August", "September",
	    "October", "November", "December"
	];
	
	Date.prototype.getMonthName = function() {
	    return this.monthNames[this.getMonth()];
	};
	Date.prototype.getShortMonthName = function () {
	    return this.getMonthName().substr(0, 3);
	};
}
*/
function loadAvailableTimesUI() {
	var url = '/api/v1/available-inpsection-times/' + buildingNumber;
	if(allSectors) {
		url += "?allSectors=true";
	}
	$.ajax(
		{
			url: url,
			cache: false
		}	
	).success(function(data) {
		times = {};
		$.each(data, function(index, appt){
			var d = new Date(appt.periodStart);
			var month = times[getMonthNameFromDate(d)];
			if(!month) {
				month = { name: getMonthNameFromDate(d) };
				month.num = d.getMonth();
				times[month.name] = month;
				
			}
			
			var day = month[d.getDate()];
			if(!day) {
				day = { day: d.getDate(), slots: []};
				month[day.day] = day;
			}
			
			day.slots.push(appt);
		});
		
		var monthList = [];
		for(i in times) {
			monthList.push(times[i]);
		}
		monthList.sort(function(first, second) {
			return first.num - second.num;
		});
		var monthCount = 0;
		$.each(monthList, function(index, month) {
			$('.available-months').append(monthOption(month))
			monthCount++;
		});
		
		if(monthCount > 0) {
			$('.available-months a').first().click();
		}
	});
}

function getStartDayInMonth(month) {
	var d = new Date();
	d.setMonth(month);
	d.setDate(1);
	return d.getDay();
}

function getDaysInMonth(month) {
	var d = new Date();
	d.setMonth(month);
	d.setDate(1);
	var start = d.getTime();
	if(month == 11) {
		d.setMonth(0);
		d.setFullYear(d.getFullYear() + 1);
	}
	else {
		d.setMonth(d.getMonth() + 1);
	}
	
	var then = d.getTime()
	
	then += 60 * 60 * 1000;
	
	return Math.floor((then - start) / (24 * 60 * 60 * 1000));
}

function zeroPrefix(val) {
	var s = '' + val;
	if(s.length == 1) {
		s = '0' + s;
	}
	return s;
}

function renderTimeSlotsInDetailView(day, monthName, dayNum) {
	$('.available-times').html('<h2>' + monthName + " " + dayNum + '</h2><p>Click the time below to schedule.</p>');
	$.each(day.slots, function(index, val) {
		var start = new Date(val.periodStart);
		var end = new Date(val.periodEnd);
		
		var startMod = start.getHours() >= 12 ? "pm" : "am";
		var endMod = end.getHours() >= 12 ? "pm" : "am";
		
		val.humanRange = twelveHour(start.getHours()) + ':' + zeroPrefix(start.getMinutes()) + startMod + 
		' - ' + twelveHour(end.getHours()) + ':' + zeroPrefix(end.getMinutes()) + endMod;
		val.startTimestamp = new Date(val.periodStart).getTime();
		val.endTimestamp = new Date(val.periodEnd).getTime();
		if(isAdmin) {
			$('.available-times').append(adminTimeSlot(val));
		}
		else {
			$('.available-times').append(timeSlot(val));
		}
	});
}

function twelveHour(val) {
	return val > 12 ? val - 12 : val;
}
$(function() {
	$('.available-months').on('click', 'a', function(evt) {
		evt.preventDefault();
		var monthName = $(this).attr('data-month-name');
		var month = times[monthName];
		$('.calendar-view').html('');
		
		var daysInMonth = getDaysInMonth(month.num);
		for(var i = 1; i <= daysInMonth; i++) {
			var styles = '';
			var dayInMonth = getStartDayInMonth(month.num);
			if(i == 1 && dayInMonth > 0) {
				styles = 'margin-left: ' + (dayInMonth * 14.285714286) + '%';
			}
			var classes = '';
			if(month[i]) {
				classes = 'has-slots';
			}
			$('.calendar-view').append('<div class="day ' + classes + '" ' +
					' data-month="' + month.name + '" ' +
					' data-day="' + i + '" style="' + styles +'" ><div class="vert-center">' + i + '</div></div>')
		}
		
		$('.available-times').html('Choose a day to see the available times.');
		$('.available-months a').removeClass('selected');
		$(this).addClass('selected');
	});
	
	$('.calendar-view').on('click', '.day', function(evt){
		evt.preventDefault();
		var monthName = $(this).attr('data-month');
		var dayNum = $(this).attr('data-day');
		
		var day = times[monthName][dayNum];
		if(!day) {
			$('.available-times').html('<h2>' + monthName + " " + dayNum + '</h2><p>No times are available on this day.</p>');
		}
		else {
			renderTimeSlotsInDetailView(day, monthName, dayNum);
		}
	});
});








