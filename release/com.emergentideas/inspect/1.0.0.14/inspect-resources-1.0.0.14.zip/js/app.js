$(function() {
	$('#constructed').datepicker();
	$('#startDate').datepicker();
	$('#startTime').timepicker();
	$('#endTime').timepicker();
	$('#date').datepicker();
	$('#sourceDate').datepicker();
	$('#destinationDate').datepicker();
	
});

function parseTimes(data) {
	console.log(typeof data);
}