$(function() {
	$('#constructed').datepicker();
	$('#startDate').datepicker();
	$('#endDate').datepicker();
	$('#startTime').timepicker();
	$('#endTime').timepicker();
	$('#date').datepicker();
	$('#sourceDate').datepicker();
	$('#destinationDate').datepicker();
	
});

function parseTimes(data) {
	console.log(typeof data);
}

dropHasFiles = function(evt) {
	var files = evt.originalEvent.target.files
			|| evt.originalEvent.dataTransfer.files
	if(files.length > 0) {
		return true
	}
	if(evt.originalEvent.dataTransfer.items && evt.originalEvent.dataTransfer.items.length > 0) {
		if(evt.originalEvent.dataTransfer.items[0].kind == 'file') {
			return true
		}
	}
	return false
}

var cleanFilename = function(filename) {
	return filename.split("%20").join("-").split(" ").join("-").split(",").join("-")
}


var curInputNum = 1

function createDropUpload(domTarget) {
	var inputName = 'videoraw'
	var nameName = 'videoname'
	var $container = $(domTarget)
	
	
	var readerOnLoad = function (reader, name) {
		name = cleanFilename(name)
		var fileData = reader.result
		$('#' + inputName + curInputNum).val(fileData)
		$('#' + nameName + curInputNum++).val(name)
		
		$container.append('<p>Will upload: ' + name + '</p>')
		
	}
	
	$container.on('dragenter', function (e) {
		if(dropHasFiles(e)) {
			e.stopPropagation()
			e.preventDefault()
			$container.addClass('about-to-drop')
		}
	});
	$container.on('dragover', function (e) {
		if(dropHasFiles(e)) {
			e.stopPropagation()
			e.preventDefault()
			$container.addClass('about-to-drop')
		}
	});
	$container.on('dragstop dragend', function (e) {
		if(dropHasFiles(e)) {
			e.stopPropagation()
			e.preventDefault()
		}
	})
	$container.on('dragleave', function (e) {
		if(dropHasFiles(e)) {
			e.stopPropagation()
			e.preventDefault()
			if($(e.target).hasClass('about-to-drop')) {
				$container.removeClass('about-to-drop')
			}
		}
	});
	$container.on('drop', function(evt) {
		if(dropHasFiles(evt)) {
			evt.stopPropagation()
			evt.preventDefault()
			$container.removeClass('about-to-drop')
			
			var files = evt.originalEvent.target.files
					|| evt.originalEvent.dataTransfer.files
			
			
			for(var i = 0; i < files.length; i++) {
				var file = files[i]
				function createReader(file) {
					var reader  = new FileReader()
					
					reader.onloadend = function() {
						readerOnLoad(reader, file.name)
					}
					reader.readAsDataURL(file)
				}
				createReader(file)
			}

		}
	});

}


$('.video-drop-area').each(function() {
	createDropUpload(this)
})
