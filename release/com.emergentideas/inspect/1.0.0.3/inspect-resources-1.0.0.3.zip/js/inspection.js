window.indexedDB = window.indexedDB || window.webkitIndexedDB || window.mozIndexedDB || window.OIndexedDB || window.msIndexedDB;
IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction || window.OIDBTransaction || window.msIDBTransaction;

callForUpdate = false;

function empty(val) {
	if(typeof val === 'undefined') {
		return true;
	}
	if(val == null) {
		return true;
	}
	var v = val + '';
	if(v.trim() == '') {
		return true;
	}
	
	return false;
}

dbVersion = 3;
var request = indexedDB.open("inspect", dbVersion);
idBase = new Date().getTime();

/**
 * Keeps a count of which long running operation we're performing. If the number is
 * different for an operation than what it started with, the operation should probably
 * stop. 
 */
operationCount = 0;

function canRun(startedOperationCount) {
	if(typeof startedOperationCount == 'undefined') {
		return true;
	}
	return startedOperationCount == operationCount;
}

function newOperation() {
	operationCount += 1;
	return operationCount;
}

function upgradedb(db) {
	if(db.objectStoreNames.contains("building") == false){
	    obstore = db.createObjectStore("building", { keyPath: "id" });
	    obstore = db.createObjectStore("buildingoverlay", { keyPath: "id" });
		
	    obstore = db.createObjectStore("address", { keyPath: "id" });
	    obstore = db.createObjectStore("addressoverlay", { keyPath: "id" });
	    
	    obstore = db.createObjectStore("contact", { keyPath: "id" });
	    obstore = db.createObjectStore("contactoverlay", { keyPath: "id" });
	}
	if(db.objectStoreNames.contains("picdata") == false){
	    obstore = db.createObjectStore("picentry", { keyPath: "id" });
	    obstore = db.createObjectStore("picdata", { keyPath: "id" });
	}
}

request.onsuccess = function (event) {
    db = request.result;
    
    db.onerror = function (event) {
    	console.log("Could not open db.");
    };
    
    // check for lack of upgrade support
    if (db.setVersion) {
        if (db.version != dbVersion) {
            var setVersion = db.setVersion(dbVersion);
            setVersion.onsuccess = function () {
                upgradedb(db);
            };
        }
    }
    
    $(startup);
}
 
request.onupgradeneeded = function(event) {
	db = event.target.result;
	upgradedb(db);
}


function genId() {
	return idBase++;
}

/* an array of building objects */
function consumeListOfBuildings(buildings, curOperation) {
	if(!canRun(curOperation)) {
		console.log("cancel operation");
		return;
	}
	var trans = db.transaction(["building", "address", "contact"], "readwrite");
	var buildingStore = trans.objectStore("building");
	var addressStore = trans.objectStore("address");
	var contactStore = trans.objectStore("contact");
	
	$.each(buildings, function() {
		if(!canRun(curOperation)) {
			console.log("cancel operation");
			return false;
		}
		if(this.buildingLocation) {
			var buildingLocation = this.buildingLocation; 
			addressStore.put(buildingLocation);
			this.buildingLocation = buildingLocation.id;
		}
		if(this.ownerAddress) {
			var ownerAddress = this.ownerAddress; 
			addressStore.put(ownerAddress);
			this.ownerAddress = ownerAddress.id;
		}
		if(this.ownerContact) {
			var ownerContact = this.ownerContact; 
			contactStore.put(ownerContact);
			this.ownerContact = ownerContact.id;
		}
		if(this.residentContact) {
			var residentContact = this.residentContact; 
			contactStore.put(residentContact);
			this.residentContact = residentContact.id;
		}
		buildingStore.put(this);
	});
}

function setActiveArea(val) {
	$('#active-area').html(val);
}

function appendActiveArea(val) {
	$('#active-area').append(val);
}

function formToObject(formElement, dataObject) {
	var $formElement = $(formElement);
	$formElement.find('input').each(function() {
		var name = $(this).attr('name');
		if(name) {
			dataObject[name] = $(this).val();
		}
	});
	$formElement.find('textarea').each(function() {
		var name = $(this).attr('name');
		if(name) {
			dataObject[name] = $(this).val();
		}
	});
	$formElement.find('select').each(function() {
		var name = $(this).attr('name');
		if(name) {
			dataObject[name] = $(this).val();
		}
	});
	return dataObject;
}

function saveToLocalStorage(prefix, dataObject) {
	$.each(Object.keys(dataObject), function() {
		localStorage.setItem(prefix + '.' + this, JSON.stringify(dataObject[this]));
	});
	return dataObject;
}

function getFromLocalStorage(prefix, dataObject) {
	$.each(Object.keys(dataObject), function() {
		dataObject[this] = JSON.parse(localStorage.getItem(prefix + '.' + this));
	});
	return dataObject;
}

function saveUserInfo(userInfo) {
	saveToLocalStorage('userInfo', userInfo);
}

function getUserInfo() {
	return getFromLocalStorage('userInfo', new UserInfo());
}

function ajaxErrorHandler(evt) {
	var resp = evt.responseText;
	if(resp) {
		resp = resp.trim();
	}
	if(evt.status == 409) {
		if(resp && resp == 'auth failed') {
			setActiveArea(authError())
			return;
		}
	}
	if(evt.status == 0) {
		setActiveArea(serverUnreachableError())
		return;
	}
	
	setActiveArea(unknownAPIError());
}

function isPasswordValid(userId, password, yesCallback, noCallback, noConnectionCallback) {
	$.ajax('/api/v1/password-test', {
		cache: false,
		beforeSend: function(xhr) {xhr.setRequestHeader("Authorization", "Basic " + btoa(userId + ":" + password));}
	}).fail(function(evt) {
		var resp = evt.responseText;
		if(resp) {
			resp = resp.trim();
		}
		if(evt.status == 409) {
			if(resp && resp == 'auth failed') {
				if(noCallback) {
					noCallback();
				}
				return;
			}
		}
		if(evt.status == 0) {
			if(noConnectionCallback) {
				noConnectionCallback();
			}
			return;
		}
		if(noCallback) {
			noCallback();
		}
	})
	.done(function(data) {
		if(data && typeof data == 'string') {
			data = data.trim();
		}
		if('yep' === data) {
			if(yesCallback) {
				yesCallback();
			}
		}
		else {
			if(noCallback) {
				noCallback();
			}
		}
	});

}

function getIfConnected(url, callback) {
	$.ajax('/api/v1/connection-test', {
		cache: false,
		beforeSend: authHeaderFunction
	}).fail(function(evt) {
			var resp = evt.responseText;
			if(resp) {
				resp = resp.trim();
			}
			if(evt.status == 409) {
				if(resp && resp == 'auth failed') {
					setActiveArea(authError())
					return;
				}
			}
			if(evt.status == 0) {
				setActiveArea(notConnectedMessage())
				return;
			}
			
			setActiveArea(unknownAPIError());
	})
	.done(function(data) {
		$.ajax(url, {
			cache: false,
			beforeSend: authHeaderFunction
		}).fail(ajaxErrorHandler)
		.done(callback);
	});

}

// data access classes

/**
 * Returns all items with a callback for each item.
 */
function getItems(storeName, callback, curOperationCount, allDoneCallback) {
	var objectStore = db.transaction([storeName]).objectStore(storeName);
	objectStore.openCursor().onsuccess = function(event) {
		var cursor = event.target.result;
		if(!canRun(curOperationCount)) {
			console.log("No more getting items. We are on to a new operation.")
			return;
		}
		if (cursor) {
			callback(cursor.value);
			cursor.continue();
		}
		else {
			if(typeof allDoneCallback == 'function') {
				allDoneCallback();
			}
		}
	};
}

/**
 * Returns all items with a callback at the end with the list
 */
function getAllItems(storeName, callback, curOperationCount) {
	var objectStore = db.transaction([storeName]).objectStore(storeName);
	var all = [];
	objectStore.openCursor().onsuccess = function(event) {
		var cursor = event.target.result;
		if(!canRun(curOperationCount)) {
			console.log("No more getting items. We are on to a new operation.")
			return;
		}
		if (cursor) {
			all.push(cursor.value);
			cursor.continue();
		}
		else {
			callback(all);
		}
	};
}


function getSaveStoreName(storeName) {
	if(storeName.indexOf('overlay') >= 0) {
		return storeName;
	}
	if(storeName.indexOf('address') == 0) {
		return 'addressoverlay';
	}
	if(storeName.indexOf('contact') == 0) {
		return 'buildingoverlay';
	}
	if(storeName.indexOf('building') == 0) {
		return 'buildingoverlay';
	}
	
	return storeName;
}

/** 
 * saves an object in the overlay store
 * @param storeName
 * @param obj
 */
function saveObject(storeName, obj) {
	var actualStore = getSaveStoreName(storeName);
	var objectStore = db.transaction([actualStore], "readwrite").objectStore(actualStore);
	objectStore.put(obj);
}

function syncObject(storeName, obj) {
	
	var trans = db.transaction([storeName, storeName + 'overlay'], "readwrite");
	var objectStore = trans.objectStore(storeName);
	objectStore.put(obj);
	objectStore = trans.objectStore(storeName + 'overlay');
	objectStore.delete(obj.id);
}

function doesDatabaseHaveStore(storeName) {
	var hasIt = false;
	$.each(db.objectStoreNames, function() {
		if(storeName == (this + '')) {
			hasIt = true;
			return false;
		}
	});
	return hasIt;
}

function getObject(storeName, id, callback) {
	if(typeof id === 'undefined' || !id) {
		callback(null);
		return;
	}
	if(typeof id === 'string') {
		id = parseInt(id);
	}
	else if(typeof id === 'object') {
		id = parseInt(id.toString());
	}
	if(typeof id === 'undefined' || !id) {
		callback(null);
		return;
	}
	
	var hasOverlay = doesDatabaseHaveStore(storeName + 'overlay');
	
	var trans;
	if(hasOverlay) {
		trans = db.transaction([storeName, storeName + 'overlay']);
		var objectStore = trans.objectStore(storeName + 'overlay');
		objectStore.get(id).onsuccess = function (event) {
		    var val = event.target.result;
		    if(val) {
		    	callback(val);
		    }
		    else {
			    var orgStore = trans.objectStore(storeName);
			    orgStore.get(id).onsuccess = function(event) {
			    	var orgVal = event.target.result;
			    		callback(orgVal);
			    }
		    }
		}
	}
	else {
		trans = db.transaction([storeName]);
		var objectStore = trans.objectStore(storeName);
		objectStore.get(id).onsuccess = function (event) {
		    var val = event.target.result;
		    callback(val);
		}
	}
}

function getAddress(id, callback) {
	getObject("address", id, callback);
}

function saveAddress(address) {
	saveObject("address", address);
}

function getContact(id, callback) {
	getObject("contact", id, callback);
}

function saveContact(contact) {
	saveObject("contact", contact);
}

function getBuilding(id, callback) {
	getObject("building", id, function(building){
		callback(building);
	});
}

function saveBuilding(building) {
	saveObject("building", building);
}


function getCompleteBuilding(id, callback) {
	getObject("building", id, function(building){
		getAddress(building.buildingLocation, function(address) {
			building.buildingLocation = address;
			getAddress(building.ownerAddress, function(address) {
				building.ownerAddress = address;
				getContact(building.ownerContact, function(contact) {
					building.ownerContact = contact;
					getContact(building.residentContact, function(contact) {
						building.residentContact = contact;
						callback(building);
					});
				});
			});
		});
	});
}

//// notes data access classes
//function getAllNotes(callback) {
//	var objectStore = db.transaction(["notes"]).objectStore("notes");
//	var allNotes = [];
//	objectStore.openCursor().onsuccess = function(event) {
//		var cursor = event.target.result;
//		if (cursor) {
//			allNotes.push(cursor.value);
//			cursor.continue();
//		}
//		else if(callback) {
//			callback(allNotes);
//		}
//	};
//}
//
//function loadNote(id, callback) {
//	var objectStore = db.transaction(["notes"]).objectStore("notes");
//	objectStore.get(id).onsuccess = function (event) {
//	    var val = event.target.result;
//	    callback(val);
//	};
//}


function saveNote(note) {
	var objectStore = db.transaction(["notes"], "readwrite").objectStore("notes");
	if(note.id) {
		objectStore.put(note, note.id);
	}
	else {
		note.id = genId() + '';
		objectStore.put(note, note.id);
	}
}

function deleteObject(dataType, id) {
	var objectStore = db.transaction([dataType], "readwrite").objectStore(dataType);
	objectStore.delete(id);
}

function showAllBuildings() {
	var $active = $('#active-area');
	var curCount = newOperation();
	$active.empty();
	getItems("building", function(building) {
		getAddress(building.buildingLocation, function(address) {
			if(!canRun(curCount)) return;
			$active.append('<a href="#building/' + building.id + '" class="building-link" data-id="' + building.id + 
					'">buildingId=' + building.id + ', ' + displayAddressLinear(address) + "</a><br/>");
		});
	}, curCount);
}

function authHeaderFunction(xhr) {
	var userInfo = getUserInfo();
	xhr.setRequestHeader("Authorization", "Basic " + btoa(userInfo.userId + ":" + userInfo.password));
}
function fetchBuildings() {
	var curCount = newOperation();
	$('#active-area').empty().append("<p>Fetching data from server.</p>");
	getIfConnected('/api/v1/building/all', function(data) {
		$('#active-area').empty().append("<p>Saving data locally.</p>");
		consumeListOfBuildings(data, curCount);
		$('#active-area').empty().append("<p>Done saving data.</p>");
	});
	
}

function postDataAsBody(url, dataObj, doneCallback) {
	var dat = JSON.stringify(dataObj);
	if(dat.indexOf('[') != 0) {
		dat = '[' + dat + ']';
	}

	$.ajax(url, {
		cache: false,
		method: 'POST',
		beforeSend: authHeaderFunction,
		data: dat,
		processData: false
	}).fail(ajaxErrorHandler)
	.done(function(data) {
		if(typeof doneCallback == 'function') {
			doneCallback(data);
		}
	});

}
function syncPics(curOperation) {
	appendActiveArea("<p>Syncing photos</p>");
	getItems('picentry', function(entry) {
		if(entry.dirty) {
			getObject('picdata', entry.id, function(data) {
				var composite = _.extend({}, entry, data);
				appendActiveArea(pushingPhoto(entry));
				postDataAsBody('/api/v1/save-picture', composite, function(response) {
					if(response.trim() == 'yep') {
						entry.dirty = false;
						saveObject("picentry", entry);
					}
				});
			});
		}
	}, curOperation,
	function() {
		appendActiveArea('<p>Done Syncing Pictures</p>');
	});
}
function syncAddresses() {
	syncType("address");
}
function syncType(type) {
	var curOperation = newOperation();
	setActiveArea("<p>" + type + ": Finding objects that need to sync.</p>");
	getAllItems(type + "overlay", function(objects) {
		if(objects.length == 0) {
			setActiveArea("<p>" + type + ": None to sync.</p>");
			return;
		}
		postDataAsBody('/api/v1/' + type + '/sync', objects, function(data) {
			setActiveArea("<p>" + type + ": Updating local store</p>");
			$.each(data, function() {
				syncObject(type, this);
			});
			setActiveArea("<p>" + type + ": Synced</p>");
		});
	}, curOperation);
}

function createSyncStatus(dataType, callback, curOperationCount) {
	var status = {
			total: 0,
			dirty: 0
	};
	
	var storeName = getSaveStoreName(dataType);
	var trans = db.transaction([storeName], "readwrite");
	var objectStore = trans.objectStore(storeName);
	objectStore.openCursor().onsuccess = function(event) {
		var cursor = event.target.result;
		if(!canRun(curOperationCount)) {
			console.log("No more getting status. We are on to a new operation.")
			return;
		}
		if (cursor) {
			status.total++;
			if(cursor.value.dirty) {
				status.dirty++;
			}
			cursor.continue();
		}
		else {
			callback(status);
		}
	};
}

function savePicture(id, data, mimeType, fileName) {
	var picentry = {
			id: id,
			dataFilename: fileName,
			mimeType: mimeType,
			dirty: true
		};
	var picdata = {
		id: id,
		data: data
	};
	saveObject("picentry", picentry);
	saveObject("picdata", picdata);
	return [picentry, picdata];
}

function loadPicture(id, callback) {
	getObject('picentry', id, function(picentry) {
		getObject('picdata', id, function(picdata) {
			callback([picentry, picdata]);
		});
	});
}


function configureRouting() {
	if(!hasher.getPreviousHash) {
		hasher.getPreviousHash = function() {
			return hasher.previousHash || location.hash;
		}
	}
	crossroads.addRoute('home', function() {
		newOperation();
		var userInfo = getUserInfo();
		if(empty(userInfo.userId) || empty(userInfo.password) || empty(userInfo.inspectorName)) {
			setActiveArea(userInfoControlPanel());
		}
		else {
			setActiveArea(controlPanel());
		}
	});
	crossroads.addRoute('sync-status', function() {
		var op = newOperation();
		$('#active-area').html(syncStatus());
		$.each(['address', 'contact', 'building', 'picentry'], function() {
			var group = '.' + this;
			createSyncStatus(this, function(status) {
				$(group + ' .dirty').html(status.dirty);
				$(group + ' .total').html(status.total);
			}, op)
		});
	});
	crossroads.addRoute('all-buildings', function() {
		newOperation();
		showAllBuildings();
	});
	crossroads.addRoute('building/{id}', function(id) {
		newOperation();
		getCompleteBuilding(id, function(building) {
			$('#active-area').empty().append(displayBuilding(building));
		});
	});
	crossroads.addRoute('building/{id}/inspect', function(id) {
		newOperation();
		var inspectWidget = null;
		if(typeof currentInspection != 'undefined') {
			if(id == currentInspection.building.id) {
				inspectWidget = new BuildingInspectionWidget({ inspection: currentInspection});
				setActiveArea(inspectWidget.el);
				inspectWidget.render();
			}
		}
		if(!inspectWidget) {
			getCompleteBuilding(id, function(building) {
				currentInspection = {building: building, inspectionRecord: new InspectionRecord()};
				inspectWidget = new BuildingInspectionWidget({ inspection: currentInspection});
				setActiveArea(inspectWidget.el);
				inspectWidget.render();
			});
		}
	});
	crossroads.addRoute('address/{id}', function(id) {
		newOperation();
		getAddress(id, function(address) {
			var addr = new EditAddressWidget({returnTo: hasher.getPreviousHash(), address: address});
			var result = addr.render();
			$('#active-area').empty().append(addr.el);
		});
	});
	crossroads.addRoute('fetch-buildings', function() {
		fetchBuildings();
	});
	crossroads.addRoute('sync-addresses', function() {
		syncAddresses();
	});
	crossroads.addRoute('sync-pics', function() {
		setActiveArea('');
		syncPics(newOperation());
	});
	crossroads.addRoute('user-info', function() {
		var userInfoWidget = new EditUserInfoWidget();
		userInfoWidget.render();
	});
	crossroads.addRoute('show-pics', function() {
		setActiveArea(showPics());
		getItems("picentry", function(entry) {
			$('.pics').append(showPicLink(entry));
		});
	});
	crossroads.addRoute('show-pic/{id}', function(id) {
		
		getObject("picentry", id, function(entry) {
			getObject("picdata", id, function(data) {
				var composite = _.extend({}, entry, data);
				setActiveArea(showPic(composite));
			});
		});
	});
	crossroads.addRoute('pic-test', function() {
		var pictest = new PicCapture({
			picList: []
		});
		setActiveArea(pictest.el);
		pictest.render();
	});
	crossroads.addRoute('update-app-version', function() {
		callForUpdate = true;
		window.applicationCache.update();
	});
	
	crossroads.addRoute('control-panel', function() {
		$('#active-area').empty().append(controlPanel());
	});
	
	crossroads.addRoute('all-addresses', function() {
		var $active = $('#active-area');
		$active.empty();
		getItems("address", function(address) {
			$active.append(displayAddressLinear(address) + "<br/>");
		});
	});
	
	crossroads.routed.add(console.log, console); //log all routes
	 
	//setup hasher
	function parseHash(newHash, oldHash){
	  crossroads.parse(newHash);
	  hasher.previousHash = oldHash;
	}
	hasher.initialized.add(parseHash); //parse initial hash
	hasher.changed.add(parseHash); //parse hash changes
	hasher.init(); //start listening for history change
	hasher.setHash('home');
}

// notes handlers
function startup() {
	configureRouting();
	
	$('#active-area').on('click', '.note-summary .delete', function(evt) {
		evt.preventDefault();
		var $noteSummary = $(this).closest('.note-summary');
		var id = $noteSummary.attr('data-id');
		deleteNote(id);
		$noteSummary.remove();
	});

	$('#active-area').on('click', '.note-summary .sync', function(evt) {
		evt.preventDefault();
		var $noteSummary = $(this).closest('.note-summary');
		var id = $noteSummary.attr('data-id');
		
		loadNote(id, function(note) {
			note.dirty = false;
			saveNote(note);
			$noteSummary.replaceWith(noteSummary(note));
		});
	});

	$('#active-area').on('submit', '.note-edit-form', function(evt) {
		evt.preventDefault();
		var v = $('.note-edit-form').serializeArray();
		
		var obj = {};
		$.each(v, function() {
			obj[this.name] = this.value;
		});
		obj.dirty = true;
		saveNote(obj);
	});
	
	function onUpdateReady() {
		try {
			window.location = '/inspection.html';
		}
		catch(e) {}
		setActiveArea("<p>Application updated.</p>");
	}
	window.applicationCache.addEventListener('updateready', onUpdateReady);
	if(window.applicationCache.status === window.applicationCache.UPDATEREADY) {
		callForUpdate = false;
		onUpdateReady();
	}
	window.applicationCache.addEventListener('noupdate', function() {
		if(callForUpdate) {
			setActiveArea("<p>Application already at latest version.</p>");
			callForUpdate = false;
		}
	});
	console.log("ran start up script");
}


CKEDITOR.disableAutoInline = true;
CKEDITOR.config.extraPlugins = '';
CKEDITOR.config.allowedContent = true;
CKEDITOR.config.disableNativeSpellChecker = false;
CKEDITOR.config.filebrowserBrowseUrl = null;
CKEDITOR.config.filebrowserImageBrowseUrl = null;
CKEDITOR.config.filebrowserUploadUrl = null;


