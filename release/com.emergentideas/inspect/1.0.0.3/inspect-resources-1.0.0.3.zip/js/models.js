UserInfo = function() {
	this.inspectorName = null;
	this.userId = null;
	this.password = null;
};

InspectionRecord = function() {
	this.pictures = [];
	this.inspectorSig = null;
	this.residentSig = null;
	this.diagram = null;
}

EditAddressWidget = Backbone.View.extend({

	address: null,
	returnTo: null,
	dirty: false,

	initialize: function(options){
		_.bindAll(this, 'render', 'submitted', 'changed');
		_.extend(this, options);
	},

	events: {
		'submit form': 'submitted',
		'change input': 'changed'
	},

	render: function() {
		this.$el.append(editAddress());
		this.$el.binddata(this.address);
	},

	submitted: function(evt) {
    	evt.preventDefault();
		if(this.dirty) {
			this.address.dirty = true;
			saveAddress(this.address);
		}
        hasher.setHash(this.returnTo);
	}, 
	
    changed:function(evt) {
        var changed = evt.currentTarget;
        var value = $(evt.currentTarget).val();
        this.address[$(changed).attr('name')] = value;
        this.dirty = true;
	}

});

BoundEditor = Backbone.View.extend({
	dataObject: null,
	dirty: false,
	templateName: null,

	initialize: function(options){
		_.bindAll(this, 'render', 'changed');
		_.extend(this, options);
	},

	events: {
		'change input': 'changed',
		'change select': 'changed'
	},

	render: function() {
		this.$el.append(Tripartite.templates[this.templateName]());
		this.$el.binddata(this.dataObject);
		var wid = this;
		this.$el.find('.ckeditor').ckeditor({
			on: {
				change: function(event) {
					wid.changed(event);
				}
			}
		});
	},
    changed:function(evt) {
    	var value;
    	var name;
    	if(evt.editor) {
    		value = evt.editor.getData();
    		name = evt.editor.name;
    	}
    	else {
	        var changed = evt.currentTarget;
	        value = $(evt.currentTarget).val();
	        name = $(changed).attr('name');
    	}
        this.dataObject[name] = value;
        this.dirty = true;
        this.dataObject.dirty = true;
	}
});

EditUserInfoWidget = Backbone.View.extend({

	userInfo: null,

	initialize: function(options){
		this.userInfo = getUserInfo();
		_.bindAll(this, 'render', 'submitted', 'testPassword');
		_.extend(this, options);
	},

	events: {
		'submit form': 'submitted',
		'click .test': 'testPassword'
	},

	render: function() {
		this.$el.append(userInformationForm());
		this.$el.binddata(this.userInfo);
		setActiveArea(this.el);
	},

	submitted: function(evt) {
    	evt.preventDefault();
		formToObject(this.$el, this.userInfo);
		saveUserInfo(this.userInfo);
        hasher.setHash('home');
	},
	
	testPassword: function(evt) {
		evt.preventDefault();
		var tempUserInfo = formToObject(this.$el, new UserInfo());
		var self = this;
		isPasswordValid(tempUserInfo.userId, tempUserInfo.password, 
				function() {self.$el.find('.messages').html("Password works.")},
				function() {self.$el.find('.messages').html("Password does not work.")},
				function() {self.$el.find('.messages').html("Couldn't connect to server.")}
		);
	}
	
});


PicCapture = Backbone.View.extend({

	picList: null,
	returnTo: null,
	dirty: false,

	initialize: function(options){
		_.bindAll(this, 'render', 'capture', 'deleteCapture');
		_.extend(this, options);
	},

	events: {
		'change .image-capture': 'capture',
		'click .delete-captured-image': 'deleteCapture'
	},

	render: function() {
		this.$el.append(captureImage());
		var self = this;
		$.each(this.picList, function() {
			loadPicture(this, function(parts) {
				self.$el.find('.captures').append(capturedImage(_.extend({}, parts[0], parts[1])));
			});
		});
	},

    capture: function(jevt) {
    	var evt = jevt.originalEvent;
    	$inputs = $('.image-capture');
    	var file;
    	if($inputs[0].files && $inputs[0].files.length > 0) {
    		file = $inputs[0].files[0];
    	}
    	var self = this;
    	var reader  = new FileReader();

    	reader.onloadend = function () {
    		var id = genId();
    		var picentry = {
    			id: id,
    			dataFilename: file.name,
    			mimeType: 'image/jpeg',
    			dirty: true
    		};
    		var picdata = {
    			id: id,
    			data: reader.result
    		};
    		saveObject("picentry", picentry);
    		saveObject("picdata", picdata);

    		self.picList.push(id);
    		var composite = _.extend({}, picentry, picdata);
    		self.$el.find('.captures').append(capturedImage(composite));
    	}
    	reader.readAsDataURL(file);

        this.dirty = true;
	},
	
	deleteCapture: function(evt) {
		evt.preventDefault();
		var $capturedTile = $(event.target).closest('.captured-image');
		var picId = $capturedTile.attr('data-id');
		deleteObject("picentry", picId);
		deleteObject("picdata", picId);
		var index = this.picList.indexOf(picId);
		if(index > -1) {
			this.picList.splice(index, 1);
		}
		$capturedTile.remove();
	}

});

BuildingInspectionWidget = Backbone.View.extend({

	className: "whole-inspection",
	
	building: null,
	dirty: false,
	inspection: null,

	initialize: function(options){
		_.bindAll(this, 'render', 'partChange');
		_.extend(this, options);
		
	},

	events: {
		'click .sub-menu a': 'partChange'
	},

	render: function() {
		this.$el.append(performInspection());
		this.$el.find('.building-info').click();
	},

	partChange: function(evt) {
		evt.preventDefault();
		var biw = this;
		var $source = $(evt.currentTarget);
		if($source.hasClass('building-info')) {
			var subWidget = new BoundEditor({templateName: 'editAddressFields', dataObject: this.inspection.building.buildingLocation});
			subWidget.render();
			this.$el.find('.inspection-parts').html(subWidget.el);
			subWidget = new BoundEditor({templateName: 'buildingFields', dataObject: this.inspection.building});
			subWidget.render();
			this.$el.find('.inspection-parts').append(subWidget.el);
		}
		if($source.hasClass('owner-info')) {
			var subWidget = new BoundEditor({templateName: 'contactFields', dataObject: this.inspection.building.ownerContact});
			subWidget.render();
			this.$el.find('.inspection-parts').html(subWidget.el);
			subWidget = new BoundEditor({templateName: 'editAddressFields', dataObject: this.inspection.building.ownerAddress});
			subWidget.render();
			this.$el.find('.inspection-parts').append(subWidget.el);
		}
		if($source.hasClass('resident-info')) {
			var subWidget = new BoundEditor({templateName: 'contactFields', dataObject: this.inspection.building.residentContact});
			subWidget.render();
			this.$el.find('.inspection-parts').html(subWidget.el);
		}
		if($source.hasClass('diagram-info')) {
			getObject('picdata', biw.inspection.inspectionRecord.diagram, function(picdata) {
				picdata = picdata || {};
				var subWidget = new PaintWidget({stamps: ['/pit.jpg', '/pump.jpg', '/drain.jpg'], 
					initialImageLocation: picdata.data,
					onImageChange: function(data) {
						var diagramId = biw.inspection.inspectionRecord.diagram;
						if(!diagramId) {
							diagramId = genId();
							biw.inspection.inspectionRecord.diagram = diagramId;
						}
						savePicture(diagramId, data, 'image/png')
				}});
				biw.$el.find('.inspection-parts').html(subWidget.el);
				subWidget.render();
			});
		}
		if($source.hasClass('resident-sig-info')) {
			getObject('picdata', biw.inspection.inspectionRecord.residentSig, function(picdata) {
				picdata = picdata || {};
				var subWidget = new PaintWidget({stamps: [], 
					initialImageLocation: picdata.data,
					onImageChange: function(data) {
						var diagramId = biw.inspection.inspectionRecord.residentSig;
						if(!diagramId) {
							diagramId = genId();
							biw.inspection.inspectionRecord.residentSig = diagramId;
						}
						savePicture(diagramId, data, 'image/png')
				}});
				biw.$el.find('.inspection-parts').html(subWidget.el);
				subWidget.render();
			});
		}
		if($source.hasClass('inspector-sig-info')) {
			getObject('picdata', biw.inspection.inspectionRecord.inspectorSig, function(picdata) {
				picdata = picdata || {};
				var subWidget = new PaintWidget({stamps: [], 
					initialImageLocation: picdata.data,
					onImageChange: function(data) {
						var diagramId = biw.inspection.inspectionRecord.inspectorSig;
						if(!diagramId) {
							diagramId = genId();
							biw.inspection.inspectionRecord.inspectorSig = diagramId;
						}
						savePicture(diagramId, data, 'image/png')
				}});
				biw.$el.find('.inspection-parts').html(subWidget.el);
				subWidget.render();
			});
		}
		if($source.hasClass('pic-info')) {
			var subWidget = new PicCapture({picList: this.inspection.inspectionRecord.pictures});
			this.$el.find('.inspection-parts').html(subWidget.el);
			subWidget.render();
		}
		PaintWidget
	}

});



PaintCanvas = Backbone.View.extend({
	buttonState: 'up',
	lastClickX: 10,
	lastClickY: 10,
	mode: 'freehand',
	oldImages: new Array(),
	canvasWidth: null,
	canvasHeight: null,
	color: 'rgb(200, 0, 0)',
	initialImageLocation: null,
	onImageChange: null,

	initialize: function(options){
		_.bindAll(this, 'render', 'drawLine', 'createCanvas', 'mouseout', 'mousedown',
				'mouseup', 'mouseover', 'mousemove', 'findx', 'findy', 'drawBox',
				'undo', 'clear', 'setLastLocation', 'getXLocation', 'getYLocation',
				'isTouchEvent', 'reconfigureCanvasForSizeChange'); // fixes loss of context for 'this' within methods
		_.extend(this, options);
		
	},

	events: {
		'mousemove canvas': 'mousemove',
		'touchmove canvas': 'mousemove',
		'mouseout canvas': 'mouseout',
		'mousedown canvas': 'mousedown',
		'touchstart canvas': 'mousedown',
		'mouseup canvas': 'mouseup',
		'touchend canvas': 'mouseup',
		'mouseover canvas': 'mouseover'
	},
	
	reconfigureCanvasForSizeChange: function() {
		this.canvasWidth = $(this.el).width();
		this.canvasHeight = $(this.el).height();
		$(this.can).width(this.canvasWidth);
		$(this.can).height(this.canvasHeight)	;
	},
	
	render: function(){

		if(!this.canvasWidth) {
			this.canvasWidth = $(this.el).width();
		}
		if(!this.canvasHeight) {
			this.canvasHeight = $(this.el).height();
		}
		
		var can = this.can = this.$el.find('canvas');
		if(can.size() == 0) {
			can = this.can = this.createCanvas();
			this.el.appendChild(can);
		}
		else {
			can = this.can = this.$el.find('canvas')[0];
		}
		
		var self = this;
		this.$el.resize(function(evt) {
			self.reconfigureCanvasForSizeChange();
		})
		
		var ctx = can.getContext('2d');
		this.ctx = ctx;
		ctx.fillStyle = this.color;

		if(this.initialImageLocation) {
			var vImage = new Image();
			vImage.onload = function() { 
				ctx.drawImage(vImage, 0, 0);
			};
			vImage.src = this.initialImageLocation;
		}

	},

	drawLine: function(ctx, x1, y1, x2, y2) {
		ctx.beginPath();
		ctx.moveTo(x1,y1);
		ctx.lineTo(x2,y2);
		ctx.stroke();
	},

	createCanvas: function() {
		var c = document.createElement('canvas');
		c.width = this.canvasWidth;
		c.height = this.canvasHeight;
		c.style.position = 'absolute';
		c.style.top = '0';
		c.style.left = '0';
		return c;
	},
	
	getXLocation: function(event) {
		if(this.isTouchEvent(event)) {
			var touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];
			return touch.pageX;
		}
		else {
			return event.pageX;
		}
	},

	getYLocation: function(event) {
		if(this.isTouchEvent(event)) {
			var touch = event.originalEvent.touches[0] || event.originalEvent.changedTouches[0];
			return touch.pageY;
		}
		else {
			return event.pageY;
		}
	},
	
	isTouchEvent: function(event) {
		try {
			return (event.originalEvent.touches && event.originalEvent.touches.length > 0) ||
				(event.originalEvent.changedTouches && event.originalEvent.changedTouches.length > 0);
		}
		catch(e) {
			return false;
		}
	},
	
	setLastLocation: function(event) {
		this.lastClickX = this.getXLocation(event);
		this.lastClickY = this.getYLocation(event);
	},
	
	mouseout: function(event) {
		if(this.mode == 'freehand') {
			this.lastClickX = -1;
			this.lastClickY = -1;
		}
		else if(this.mode == 'box' && this.topLayer) {

		}
		else if(this.mode == 'line' && this.topLayer) {

		}
		else {
			this.buttonState = 'up';
		}

	},

	mousedown: function(event) {
		if(this.isTouchEvent(event)) {
			event.preventDefault();
		}
		try {
			if(this.oldImages.length > 10) {
				this.oldImages.shift();
			}
			var imgTemp = this.ctx.getImageData(0,0,this.canvasWidth,this.canvasHeight);
			this.oldImages.push(imgTemp);

		}catch(e) {
			console.log("Could not get canvas image");
		}

		this.buttonState = 'down';
		this.setLastLocation(event);
		
		if(this.mode == 'box') {
		}
	},

	mouseup: function(event){
		if(this.mode == 'box') {
			if(this.buttonState == 'down') {
				if(this.topLayer) {
					this.el.removeChild(this.topLayer);
					this.topLayer = null;
				}
				this.drawBox(this.ctx, event);

			}
		}
		if(this.mode == 'line') {
			if(this.buttonState == 'down') {
				if(this.topLayer) {
					this.el.removeChild(this.topLayer);
					this.topLayer = null;
				}
				this.drawLine(this.ctx, this.lastClickX - this.findx(), this.lastClickY - this.findy(), this.getXLocation(event) - this.findx(), this.getYLocation(event) - this.findy());

			}
		}
		else if(this.mode == 'freehand') {
			this.lastClickX = -1;
			this.lastClickY = -1;
		}
		else if(this.mode == 'stamp') {
			this.ctx.drawImage(this.stampImg, this.lastClickX - this.findx() - (this.stampImg.naturalWidth / 2), 
					this.lastClickY - this.findy() - (this.stampImg.naturalHeight / 2));
			this.lastClickX = -1;
			this.lastClickY = -1;
		}

		this.buttonState = 'up';
		
		if(this.onImageChange) {
			this.onImageChange(this.can.toDataURL());
		}
	},

	mouseover: function(event) {
		if(this.mode == 'freehand') {
			this.lastClickX = this.getXLocation(event);
			this.lastClickY = this.getYLocation(event);
		}
		else if(this.mode == 'box') {
			var i = 87;
		}

	},

	mousemove: function(event){
		if(this.isTouchEvent(event)) {
			event.preventDefault();
		}
		if(this.mode == 'freehand') {
			if(this.buttonState == 'down') {
				if(this.lastClickX != -1) {
					this.drawLine(this.ctx, this.lastClickX - this.findx(), this.lastClickY - this.findy(), 
							this.getXLocation(event) - this.findx(), this.getYLocation(event)  - this.findy());
				}
				this.setLastLocation(event);
			}
		}
		else if(this.mode == 'box') {
			if(this.buttonState == 'down') {
				if(this.topLayer) {
					this.el.removeChild(this.topLayer);
					this.topLayer = null;
				}

				var c = this.createCanvas();
				var current = this;

				this.el.appendChild(c);
				this.topLayer = c;
				var layerContext = c.getContext('2d');

				this.drawBox(layerContext, event);
			}
		}
		else if(this.mode == 'line') {
			if(this.buttonState == 'down') {
				if(this.topLayer) {
					this.el.removeChild(this.topLayer);
					this.topLayer = null;
				}

				var c = this.createCanvas();
				var current = this;

				this.el.appendChild(c);
				this.topLayer = c;
				var layerContext = c.getContext('2d');

				this.drawLine(layerContext, this.lastClickX - this.findx(), this.lastClickY - this.findy(), this.getXLocation(event) - this.findx(), this.getYLocation(event) - this.findy());
			}
		}
	},

	findx: function() {
		var x = 0;
		var w = this.$el.find('canvas')[0];
		while(true) {
			x += w.offsetLeft;
			if(w.offsetParent) {
				w = w.offsetParent;
			}
			else {
				break;
			}
		}
		return(x);
	},

	findy: function() {
		var y = 0;
		var w = this.$el.find('canvas')[0];
		while(true) {
			y += w.offsetTop;
			if(w.offsetParent) {
				w = w.offsetParent;
			}
			else {
				break;
			}
		}
		return(y);
	},

	drawBox: function(ctx, event) {
		var width = this.lastClickX - this.getXLocation(event);
		if(width < 0) {
			width = width * -1;
		}
		var height = this.lastClickY - this.getYLocation(event);
		if(height < 0) {
			height = height * -1;
		}

		var startX;
		var startY;

		if(this.lastClickX < this.getXLocation(event)) {
			startX = this.lastClickX;
		}
		else {
			startX = this.getXLocation(event);
		}

		if(this.lastClickY < this.getYLocation(event)) {
			startY = this.lastClickY;
		}
		else {
			startY = this.getYLocation(event);
		}

		startX = startX - this.findx();
		startY = startY - this.findy();

		ctx.strokeRect(startX, startY, width, height);

	},

	undo: function(ctx) {
		if(this.oldImages.length > 0) {
			var imgTemp = this.oldImages.pop();
			this.ctx.putImageData(imgTemp, 0, 0);
		}
	},

	clear: function(ctx) {
		try {
			if(this.oldImages.length > 10) {
				this.oldImages.shift();
			}
			var imgTemp = this.ctx.getImageData(0,0,this.canvasWidth,this.canvasHeight);
			this.oldImages.push(imgTemp);
		} catch(e) {
			console.log("Could not get canvas image");
		}

		this.ctx.clearRect(0, 0, this.canvasWidth, this.canvasHeight);
	}

});

PaintWidget = Backbone.View.extend({
	
	paintCanvas: null,
	stamps: [],
	onImageChange: null,
	className: 'paint-widget',
	initialImageLocation: null,
	
	initialize: function(options){
		_.bindAll(this, 'render', 'changeStyle', 'undo', 'clear', 'chooseStamp');
		if(options.stamps) {
			this.stamps = options.stamps;
		}
		this.onImageChange = options.onImageChange;
		this.initialImageLocation = options.initialImageLocation;
	},
	
	events: {
		'click .button-row .change-style': 'changeStyle',
		'click .button-row .undo': 'undo',
		'click .button-row .clear': 'clear',
		'click .stamp-row img': 'chooseStamp'
	},
	
	render: function() {
		this.$el.append(paintWidgetTemplate());
		var self = this;
		_.each(this.stamps, function(url) {
			self.$el.find('.stamp-row').append(stampImage(url));
		});
		
		this.paintCanvas = new PaintCanvas({ el: this.$el.find('.canvas-area')[0], 
			onImageChange: this.onImageChange, 
			initialImageLocation: this.initialImageLocation});
		this.paintCanvas.render();
	},
	
	changeStyle: function(evt) {
		this.$el.find('.selected').removeClass('selected');
		$(evt.target).addClass('selected');
		this.paintCanvas.mode = $(evt.target).attr('data-style');
	},
	
	undo: function() {
		this.paintCanvas.undo();
	},
	
	clear: function() {
		this.paintCanvas.clear();
	},
	
	chooseStamp: function(evt) {
		this.$el.find('.selected').removeClass('selected');
		$(evt.target).addClass('selected');
		this.paintCanvas.mode = 'stamp';
		this.paintCanvas.stampImg = new Image(); 
		this.paintCanvas.stampImg.src = $(evt.target).attr('src');
	}

});

