CKEDITOR.plugins.add( 'slide-multi-show', {
	requires: 'widget',

    icons: 'slide-multi-show',

    init: function( editor ) {
		editor.widgets.add( 'slide-multi-show', {
         button: 'Create a Slideshow',
		 upcast: function(element) {
			 return element.name == 'div' && element.hasClass( 'slide-multi-shows-data' );
		 },
		 editables: {
			slideShowArea: {
 	            selector: '.slide-multi-shows',
				allowedContent: 'span[style]; p; img[src]'
 	        }
	    },
		template: '<div class="hd-ratio slide-multi-shows-data" data-delay="5000">' +
			'<div class="slide-multi-shows transition cross-fade arrows transform-images">' +
			'&nbsp;</div></div>'
    	} );
    }
} )