var UploadableImage = require('page-editor/uploadable-image')


$('.slide-multi-slide-form [data-image-dir]').each(function() {
	new UploadableImage(this)
})
