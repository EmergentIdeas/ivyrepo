require('crud-tools/sortable-data-table-tiles').allowItemsSort()

require("./index")()

require('./app')