﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'zh', {
	fontSize: {
		label: '大小',
		voiceLabel: '文字大小',
		panelTitle: '大小'
	},
	label: '字體',
	panelTitle: '字體',
	voiceLabel: '字體'
});
