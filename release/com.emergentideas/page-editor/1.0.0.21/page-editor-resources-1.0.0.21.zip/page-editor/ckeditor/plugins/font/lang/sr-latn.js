﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'sr-latn', {
	fontSize: {
		label: 'Veličina fonta',
		voiceLabel: 'Font Size',
		panelTitle: 'Veličina fonta'
	},
	label: 'Font',
	panelTitle: 'Font',
	voiceLabel: 'Font'
});
