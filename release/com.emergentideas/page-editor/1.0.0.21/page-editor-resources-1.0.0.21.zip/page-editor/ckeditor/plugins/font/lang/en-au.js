﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'en-au', {
	fontSize: {
		label: 'Size',
		voiceLabel: 'Font Size',
		panelTitle: 'Font Size'
	},
	label: 'Font',
	panelTitle: 'Font Name',
	voiceLabel: 'Font'
});
