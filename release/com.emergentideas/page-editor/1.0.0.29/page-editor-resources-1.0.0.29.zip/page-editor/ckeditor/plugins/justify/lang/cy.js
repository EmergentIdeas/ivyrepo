﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'cy', {
	block: 'Aliniad Bloc',
	center: 'Alinio i\'r Canol',
	left: 'Alinio i\'r Chwith',
	right: 'Alinio i\'r Dde'
});
