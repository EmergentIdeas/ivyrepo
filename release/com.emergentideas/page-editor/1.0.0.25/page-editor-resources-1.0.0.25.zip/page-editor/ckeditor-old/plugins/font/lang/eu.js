﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'eu', {
	fontSize: {
		label: 'Tamaina',
		voiceLabel: 'Tamaina',
		panelTitle: 'Tamaina'
	},
	label: 'Letra-tipoa',
	panelTitle: 'Letra-tipoa',
	voiceLabel: 'Letra-tipoa'
});
